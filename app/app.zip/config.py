import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'warnet-billing-secret-key-2024')
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///warnet.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_PERMANENT = True
    PERMANENT_SESSION_LIFETIME = 86400  # 24 jam

    # Tambahan untuk kebutuhan aplikasi
    CLIENT_API_KEY = os.environ.get('CLIENT_API_KEY', 'warnet-client-key-2024')
    DEBUG_MODE = os.environ.get('DEBUG_MODE', 'False').lower() == 'true'
    AUTO_SHUTDOWN_MINUTES = int(os.environ.get('AUTO_SHUTDOWN_MINUTES', 3))
    POLLING_INTERVAL = int(os.environ.get('POLLING_INTERVAL', 5))