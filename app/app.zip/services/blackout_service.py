# app/services/blackout_service.py
"""
BLACKOUT SERVICE - FULL MANUAL VERSION

Tidak ada yang otomatis. Kasir yang menjalankan semuanya:
1. Kasir klik "Deteksi Blackout" → sistem scan sesi aktif yang last_sync sudah lama
2. Sistem tampilkan daftar sesi terdampak (member & guest)
3. Kasir resolve per-sesi:
   - Member: kembalikan saldo ke akun
   - Guest: buka ulang di PC lain, atau tutup saja
"""

from app.models.base import now_local
from app.models.sesi import Sesi
from app.models.transaksi import Transaksi
from app.repositories.sesi_repository import SesiRepository
from app.repositories.transaksi_repository import TransaksiRepository
from app.repositories.member_repository import MemberRepository
from app.repositories.pc_repository import PCRepository
from app.utils.logger import write_log
from datetime import timedelta
from sqlalchemy import func, or_
import secrets

BLACKOUT_THRESHOLD_MENIT = 3


class BlackoutService:

    @staticmethod
    def deteksi(menit_threshold=None):
        """
        DIPANGGIL MANUAL oleh kasir via tombol "Deteksi Blackout".
        Scan sesi aktif yang last_sync-nya sudah lama, tandai is_blackout_suspect.
        Tidak ada refund atau aksi apapun di sini, hanya deteksi + catat.
        """
        threshold = menit_threshold or BLACKOUT_THRESHOLD_MENIT
        batas_waktu = now_local() - timedelta(minutes=threshold)

        sesi_list = Sesi.query.filter(
            Sesi.status == "aktif",
            Sesi.last_sync.isnot(None),
            Sesi.last_sync < batas_waktu,
            Sesi.is_blackout_suspect == False
        ).all()

        count = 0
        for sesi in sesi_list:
            sisa_saat_mati = sesi.hitung_sisa_pada(sesi.last_sync)
            lama_mati = int((now_local() - sesi.last_sync).total_seconds() / 60)

            sesi.is_blackout_suspect = True
            sesi.is_blackout_resolved = False
            sesi.sisa_menit_saat_mati = max(0, sisa_saat_mati)

            label = f"Member:{sesi.member.username}" if sesi.member else f"Guest:{sesi.nama_guest or '?'}"
            write_log(
                "BLACKOUT_DETECT",
                f"#{sesi.id} | {sesi.tipe.upper()} | {label} | "
                f"PC:{sesi.pc.kode if sesi.pc else '?'} | "
                f"Sisa: {sisa_saat_mati}m | Mati ~{lama_mati}m",
                user="kasir"
            )
            count += 1

        SesiRepository.commit()
        write_log("BLACKOUT_DETECT", f"Total terdeteksi: {count} sesi", user="kasir")
        return count

    @staticmethod
    def get_audit_list(selected_date=None):
        """Daftar sesi yang ditandai blackout, opsional filter tanggal."""
        query = Sesi.query.filter_by(is_blackout_suspect=True)
        if selected_date:
            query = query.filter(func.date(Sesi.mulai_pada) == selected_date)
        return query.order_by(Sesi.mulai_pada.desc()).all()

    @staticmethod
    def get_audit_dates():
        """Daftar tanggal yang punya audit blackout."""
        from app.models.base import db
        try:
            rows = db.session.query(func.date(Sesi.mulai_pada)) \
                .filter_by(is_blackout_suspect=True) \
                .distinct() \
                .order_by(func.date(Sesi.mulai_pada).desc()) \
                .all()
            result = []
            for row in rows:
                if row and row[0]:
                    d = row[0]
                    result.append(d if isinstance(d, str) else d.strftime("%Y-%m-%d"))
            return result
        except Exception as e:
            print(f"[ERROR] get_audit_dates: {e}")
            return []

    @staticmethod
    def resolve_member(sesi_id, operator="kasir"):
        sesi = SesiRepository.get_by_id(sesi_id)
        if not sesi:
            raise ValueError("Sesi tidak ditemukan")
        if sesi.tipe != "member":
            raise ValueError("Sesi ini bukan sesi member")
        if not sesi.is_blackout_suspect:
            raise ValueError("Sesi ini belum ditandai blackout")
        if sesi.is_blackout_resolved:
            raise ValueError("Sesi ini sudah diselesaikan")

        member = sesi.member
        if not member:
            raise ValueError("Data member tidak ditemukan")

        saldo_kembali = sesi.sisa_menit_saat_mati or 0

        # Set ulang waktu
        member.waktu_tersimpan = saldo_kembali

        # Ambil kadaluarsa dari paket terakhir via repository
        transaksi_terakhir = TransaksiRepository.get_last_paket_member(member.id)

        if transaksi_terakhir and transaksi_terakhir.paket:
            kadaluarsa_hari = transaksi_terakhir.paket.kadaluarsa_hari
            member.kadaluarsa_pada = now_local() + timedelta(days=kadaluarsa_hari)
        else:
            member.kadaluarsa_pada = now_local() + timedelta(days=30)

        sesi.status = "selesai"
        sesi.selesai_pada = now_local()
        sesi.is_blackout_resolved = True
        sesi.waktu_resolved = now_local()

        # Buat transaksi via repository
        transaksi = Transaksi(
            sesi_id=sesi.id,
            member_id=member.id,
            jenis="tutup_sesi",
            keterangan=f"Refund blackout: {saldo_kembali}m dikembalikan ke {member.username}"
        )
        TransaksiRepository.save(transaksi)  # pake repository

        SesiRepository.commit()

        write_log(...)
        return {"saldo_kembali": saldo_kembali, "username": member.username}


    @staticmethod
    def resolve_guest_sama(sesi_id, operator="kasir"):
        """Lanjutkan sesi guest di PC yang sama (paksa tutup sesi lama)"""
        sesi = SesiRepository.get_by_id(sesi_id)
        if not sesi:
            raise ValueError("Sesi tidak ditemukan")
        if sesi.tipe != "guest":
            raise ValueError("Bukan sesi guest")
        if not sesi.is_blackout_suspect:
            raise ValueError("Belum ditandai blackout")
        if sesi.is_blackout_resolved:
            raise ValueError("Sudah diselesaikan")

        pc = sesi.pc
        if not pc:
            raise ValueError("PC tidak ditemukan")
        
        # 🔥 LANGSUNG PAKSA: tutup sesi lama yang masih aktif di PC ini
        sesi_lama = SesiRepository.get_aktif_by_pc(pc.id)
        if sesi_lama and sesi_lama.id != sesi.id:
            sesi_lama.status = "selesai"
            sesi_lama.selesai_pada = now_local()
            write_log("BLACKOUT_FORCE_CLOSE", f"Paksa tutup sesi {sesi_lama.id} di PC {pc.kode}", user=operator)

        sisa = sesi.sisa_menit_saat_mati or 0
        if sisa <= 0:
            raise ValueError("Sisa waktu 0, tidak bisa dilanjutkan")

        # Tutup sesi blackout
        sesi.status = "selesai"
        sesi.selesai_pada = now_local()
        sesi.is_blackout_resolved = True
        sesi.waktu_resolved = now_local()

        # Buat sesi baru di PC yang sama
        sesi_baru = Sesi(
            tipe="guest",
            nama_guest=sesi.nama_guest,
            pc_id=pc.id,
            paket_id=sesi.paket_id,
            durasi_beli_menit=sisa,
            total_bayar=0,
            status="aktif",
            token_sesi=secrets.token_hex(32),
            mulai_pada=now_local(),
            waktu_mulai_sesi=now_local(),
            last_sync=now_local()
        )
        SesiRepository.save(sesi_baru)

        write_log("BLACKOUT_RESOLVE_GUEST_SAMA", f"{sesi.nama_guest} lanjut di PC:{pc.kode} sisa:{sisa}m", user=operator)
        return {"pc": pc.kode, "sisa_menit": sisa, "nama_guest": sesi.nama_guest}


    @staticmethod
    def resolve_guest_lanjut(sesi_id, pc_baru_id, operator="kasir"):
        sesi = SesiRepository.get_by_id(sesi_id)
        if not sesi:
            raise ValueError("Sesi tidak ditemukan")
        if sesi.tipe != "guest":
            raise ValueError("Bukan sesi guest")
        if not sesi.is_blackout_suspect:
            raise ValueError("Belum ditandai blackout")
        if sesi.is_blackout_resolved:
            raise ValueError("Sudah diselesaikan")

        pc_baru = PCRepository.get_by_id(pc_baru_id)
        if not pc_baru:
            raise ValueError("PC tujuan tidak ditemukan")
        
        # 🔥 VALIDASI GRUP: Guest hanya bisa pindah ke grup yang sama
        if sesi.pc and pc_baru.grup_id != sesi.pc.grup_id:
            raise ValueError(f"Guest hanya bisa pindah ke PC grup {sesi.pc.grup.nama.upper()}")

        if SesiRepository.get_aktif_by_pc(pc_baru.id):
            raise ValueError(f"PC {pc_baru.kode} sedang digunakan")

        sisa = sesi.sisa_menit_saat_mati or 0
        if sisa <= 0:
            raise ValueError("Sisa waktu 0, pilih 'Tutup Saja'")

        sesi.status = "selesai"
        sesi.selesai_pada = now_local()
        sesi.is_blackout_resolved = True
        sesi.waktu_resolved = now_local()

        sesi_baru = Sesi(
            tipe="guest",
            nama_guest=sesi.nama_guest,
            pc_id=pc_baru.id,
            paket_id=sesi.paket_id,
            durasi_beli_menit=sisa,
            total_bayar=0,
            status="aktif",
            token_sesi=secrets.token_hex(32),
            mulai_pada=now_local(),
            waktu_mulai_sesi=now_local(),
            last_sync=now_local()
        )
        SesiRepository.save(sesi_baru)

        write_log("BLACKOUT_RESOLVE_GUEST_LANJUT", f"{sesi.nama_guest} pindah ke PC:{pc_baru.kode} sisa:{sisa}m", user=operator)
        return {"pc_baru": pc_baru.kode, "sisa_menit": sisa, "nama_guest": sesi.nama_guest}

    @staticmethod
    def resolve_guest_tutup(sesi_id, operator="kasir"):
        """
        Kasir klik 'Tutup Saja' untuk sesi guest — tidak ada kompensasi.
        """
        sesi = SesiRepository.get_by_id(sesi_id)
        if not sesi:
            raise ValueError("Sesi tidak ditemukan")
        if sesi.tipe != "guest":
            raise ValueError("Sesi ini bukan sesi guest")
        if not sesi.is_blackout_suspect:
            raise ValueError("Sesi ini belum ditandai blackout")
        if sesi.is_blackout_resolved:
            raise ValueError("Sesi ini sudah diselesaikan")

        sesi.status = "selesai"
        sesi.selesai_pada = now_local()
        sesi.is_blackout_resolved = True
        sesi.waktu_resolved = now_local()

        transaksi = Transaksi(
            sesi_id=sesi.id,
            jenis="tutup_sesi",
            keterangan="Sesi guest ditutup kasir pasca blackout (tanpa kompensasi)"
        )
        SesiRepository.update_and_add_transaksi(transaksi)

        write_log(
            "BLACKOUT_RESOLVE_GUEST_TUTUP",
            f"Guest:{sesi.nama_guest} | PC:{sesi.pc.kode if sesi.pc else '?'} | Ditutup tanpa kompensasi",
            user=operator
        )
        return {"nama_guest": sesi.nama_guest}

    @staticmethod
    def clear_resolved(selected_date, operator="kasir"):
        """Hapus record audit yang sudah resolved berdasarkan tanggal."""
        from app.models.base import db
        deleted = Sesi.query.filter(
            Sesi.is_blackout_suspect == True,
            Sesi.is_blackout_resolved == True,
            func.date(Sesi.mulai_pada) == selected_date
        ).delete()
        db.session.commit()
        write_log("BLACKOUT_CLEAR", f"{deleted} record dihapus pada {selected_date}", user=operator)
        return deleted
    
    @staticmethod
    def force_all_and_detect(operator="kasir"):
        """Tutup semua sesi aktif, lalu deteksi blackout"""
        from app.models.sesi import Sesi
        from app.models.base import db
        from datetime import timedelta
        
        now = now_local()
        sesi_list = Sesi.query.filter_by(status="aktif").all()
        count_tutup = 0
        
        # 1. Force close semua sesi aktif
        for sesi in sesi_list:
            sesi.status = "selesai"
            sesi.selesai_pada = now
            count_tutup += 1
        
        db.session.commit()
        write_log("FORCE_CLOSE_ALL", f"{count_tutup} sesi ditutup paksa oleh {operator}", user=operator)
        
        # 2. Jalankan deteksi blackout (panggil method yang sudah ada)
        count_deteksi = BlackoutService.deteksi()
        
        return {
            "tutup": count_tutup,
            "deteksi": count_deteksi
        }