# app/services/sesi_service.py
from app.models.sesi import Sesi
from app.models.transaksi import Transaksi
from app.models.base import now_local
from app.repositories.sesi_repository import SesiRepository
from app.repositories.pc_repository import PCRepository
from app.repositories.member_repository import MemberRepository
from app.repositories.paket_repository import PaketRepository
from app.utils.logger import write_log
import secrets

class SesiService:
    @staticmethod
    def cleanup_expired():
        from datetime import timedelta
        BLACKOUT_THRESHOLD = 3  # menit, sama dengan di blackout_service
        batas_sync = now_local() - timedelta(minutes=BLACKOUT_THRESHOLD)

        sesi_aktif = SesiRepository.get_all_aktif()
        count = 0
        for sesi in sesi_aktif:
            if sesi.sisa_menit() <= 0:
                # Jangan tutup kalau last_sync sudah lama — kemungkinan blackout
                # Biarkan kasir handle lewat tab Blackout
                if sesi.last_sync and sesi.last_sync < batas_sync:
                    continue
                sesi.status = "selesai"
                sesi.selesai_pada = now_local()
                count += 1
        if count > 0: SesiRepository.commit()
        return count

    @staticmethod
    def sync_waktu_member(sesi):
        sisa = sesi.sisa_menit()
        if sesi.tipe == "member" and sesi.member:
            if sesi.member.waktu_tersimpan != sisa:
                sesi.member.waktu_tersimpan = sisa
                SesiRepository.commit()
        return sisa

    @staticmethod
    def get_detail(sesi_id):
        sesi = SesiRepository.get_by_id(sesi_id)
        return {
            "id": sesi.id, "tipe": sesi.tipe,
            "grup": sesi.pc.grup.nama if sesi.pc and sesi.pc.grup else "reguler"
        }

    @staticmethod
    def buka_guest(pc_kode, paket_id, nama_guest="Guest", operator="system"):
        pc = PCRepository.get_by_kode(pc_kode)
        if not pc: raise ValueError("PC tidak ditemukan")
        if SesiRepository.get_aktif_by_pc(pc.id): raise ValueError("PC sedang dipakai")

        paket = PaketRepository.get_by_id(paket_id)
        if not paket or not paket.aktif: raise ValueError("Paket tidak valid")
        
        # 🟢 PERBAIKAN: Bandingkan ID, bukan objek
        if paket.grup_id != pc.grup_id:
            raise ValueError(f"PC {pc.grup.nama.upper()} dilarang pakai paket {paket.grup.nama.upper()}")

        sesi = Sesi(
            tipe="guest", nama_guest=nama_guest, pc_id=pc.id, paket_id=paket.id,
            durasi_beli_menit=paket.durasi_menit, total_bayar=paket.harga,
            status="aktif", token_sesi=secrets.token_hex(32)
        )
        transaksi = Transaksi(
            paket_id=paket.id, jenis="beli_paket_guest",
            jumlah=paket.harga, menit=paket.durasi_menit,
            keterangan=f"Guest '{nama_guest}' di {pc_kode}"
        )
        SesiRepository.save_with_transaksi(sesi, transaksi)
        write_log("BUKA_GUEST", f"PC:{pc_kode} | Guest:{nama_guest}", user=operator)
        return sesi

    @staticmethod
    def buka_member(pc_kode, username, operator="system"):
        pc = PCRepository.get_by_kode(pc_kode)
        if not pc: raise ValueError("PC tidak ditemukan")
        if SesiRepository.get_aktif_by_pc(pc.id): raise ValueError("PC sedang dipakai")

        member = MemberRepository.get_by_username(username)
        if not member: raise ValueError("Member tidak ditemukan")

        # 🟢 TAMBAHKAN VALIDASI GRUP MEMBER JUGA
        if member.grup_id != pc.grup_id:
            raise ValueError(f"Member {member.grup.nama.upper()} dilarang di PC {pc.grup.nama.upper()}")

        member.cek_kadaluarsa()
        if member.waktu_tersimpan <= 0: raise ValueError("Waktu habis")

        sesi = Sesi(
            tipe="member", member_id=member.id, pc_id=pc.id, status="aktif",
            token_sesi=secrets.token_hex(32), waktu_mulai_sesi=now_local(),
            waktu_tersimpan_awal=member.waktu_tersimpan
        )
        SesiRepository.save(sesi)
        write_log("BUKA_MEMBER", f"PC:{pc.kode} | Member:{member.username}", user=operator)
        return sesi

    @staticmethod
    def tambah_waktu_sesi(sesi_id, paket, operator="system"):
        """Menambah waktu pada sesi yang sedang berjalan"""
        sesi = SesiRepository.get_aktif_by_id(sesi_id)
        if not sesi: raise ValueError("Sesi tidak aktif")

        if paket.grup_id != sesi.pc.grup_id:
            raise ValueError(f"Gagal: Paket zona {paket.grup.nama.upper()} tidak bisa dipakai di PC zona {sesi.pc.grup.nama.upper()}!")
        
        if sesi.tipe == "member" and sesi.member:
            sesi.member.tambah_waktu(paket.durasi_menit, paket.kadaluarsa_hari)
            sesi.waktu_tersimpan_awal = sesi.member.waktu_tersimpan
            
            transaksi = Transaksi(
                member_id=sesi.member.id, paket_id=paket.id, sesi_id=sesi.id,
                jenis="tambah_waktu_sesi", jumlah=paket.harga, menit=paket.durasi_menit,
                keterangan=f"Tambah waktu member {sesi.member.username}"
            )
            SesiRepository.update_and_add_transaksi(transaksi)
            
            write_log("TAMBAH_WAKTU", f"Member:{sesi.member.username} | +{paket.durasi_menit}m", user=operator)
            return {"tipe": "member", "waktu_tersimpan": sesi.member.waktu_tersimpan}

        elif sesi.tipe == "guest":
            sesi.durasi_beli_menit += paket.durasi_menit
            sesi.total_bayar += paket.harga
            
            transaksi = Transaksi(
                sesi_id=sesi.id, paket_id=paket.id, jenis="tambah_waktu_guest",
                jumlah=paket.harga, menit=paket.durasi_menit,
                keterangan=f"Tambah waktu guest {sesi.nama_guest}"
            )
            SesiRepository.update_and_add_transaksi(transaksi)
            
            write_log("TAMBAH_WAKTU", f"Guest:{sesi.nama_guest} | +{paket.durasi_menit}m", user=operator)
            return {"tipe": "guest", "sisa_menit": sesi.sisa_menit()}

        else:
            raise ValueError(f"Tipe sesi '{sesi.tipe}' tidak dikenali")

    @staticmethod
    def tutup_sesi(sesi_id, operator="system"):
        """Menutup sesi aktif"""
        sesi = SesiRepository.get_aktif_by_id(sesi_id)
        if not sesi: raise ValueError("Sesi tidak ditemukan")

        sesi.status = "selesai"
        sesi.selesai_pada = now_local()

        transaksi = Transaksi(
            sesi_id=sesi.id, member_id=sesi.member_id, jenis="tutup_sesi",
            keterangan=f"Sesi {sesi.tipe} ditutup"
        )
        SesiRepository.update_and_add_transaksi(transaksi)

        label = sesi.member.username if sesi.tipe == "member" else sesi.nama_guest
        write_log("TUTUP_SESI", f"{sesi.tipe.upper()}:{label} | PC:{sesi.pc.kode} | Main:{sesi.menit_terpakai()}m", user=operator)
        return sesi
    
    @staticmethod
    def pindah_pc(sesi_id, pc_kode_baru, operator="system"):
        """Memindahkan sesi ke PC lain"""
        sesi = SesiRepository.get_aktif_by_id(sesi_id)
        if not sesi: raise ValueError("Sesi tidak aktif")

        pc_baru = PCRepository.get_by_kode(pc_kode_baru)
        if not pc_baru: raise ValueError(f"PC {pc_kode_baru} tidak ditemukan")

        if sesi.pc.grup_id != pc_baru.grup_id:
            raise ValueError(f"Ditolak: Sesi di zona {sesi.pc.grup.nama.upper()} tidak bisa dipindah ke zona {pc_baru.grup.nama.upper()}!")

        if SesiRepository.get_aktif_by_pc(pc_baru.id): raise ValueError("PC tujuan sedang dipakai")

        pc_lama_kode = sesi.pc.kode
        sesi.pc_id = pc_baru.id

        transaksi = Transaksi(
            sesi_id=sesi.id, member_id=sesi.member_id, jenis="pindah_pc",
            keterangan=f"Pindah dari {pc_lama_kode} ke {pc_baru.kode}"
        )
        SesiRepository.update_and_add_transaksi(transaksi)

        write_log("PINDAH_PC", f"Sesi:{sesi.id} | Dari:{pc_lama_kode} | Ke:{pc_baru.kode}", user=operator)
        return {"pc_lama": pc_lama_kode, "pc_baru": pc_baru.kode, "sisa_waktu": sesi.sisa_menit()}