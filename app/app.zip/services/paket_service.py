# app/services/paket_service.py

from app.models.paket import Paket
from app.repositories.paket_repository import PaketRepository
from app.repositories.sesi_repository import SesiRepository
from app.repositories.grup_repository import GrupRepository
from app.utils.logger import write_log

class PaketService:

    @staticmethod
    def get_all(aktif_only=False, grup_nama=None):
        """Mengambil semua paket, bisa difilter berdasarkan status aktif dan nama Grup"""
        grup_id = None
        if grup_nama:
            grup_obj = GrupRepository.find_by_nama(grup_nama)
            if grup_obj:
                grup_id = grup_obj.id
        return PaketRepository.get_all(aktif_only, grup_id)

    @staticmethod
    def get_by_id(paket_id):
        """Mencari paket berdasarkan ID"""
        return PaketRepository.get_by_id(paket_id)

    @staticmethod
    def create(data, operator="system"):
        """Membuat paket baru dan menghubungkannya ke ID Grup"""
        nama = data.get("nama", "").strip()
        if not nama: 
            raise ValueError("Nama paket wajib diisi")
        
        # Cek duplikat nama
        if PaketRepository.find_by_nama(nama):
            raise ValueError(f"Paket dengan nama '{nama}' sudah ada")

        # 🔍 Cari objek grup dari nama yang dikirim frontend
        grup_nama = data.get("grup", "reguler")
        grup_obj = GrupRepository.find_by_nama(grup_nama)
        if not grup_obj: 
            raise ValueError(f"Grup '{grup_nama}' tidak ditemukan. Buat grupnya dulu bang.")

        # Buat objek Paket
        paket = Paket(
            nama=nama,
            durasi_menit=int(data.get("durasi_menit", 0)),
            harga=int(data.get("harga", 0)),
            kadaluarsa_hari=int(data.get("kadaluarsa_hari", 30)),
            grup_id=grup_obj.id, # <--- Hubungkan ke ID Grup
            aktif=True
        )
        
        # Simpan lewat Repo
        PaketRepository.save(paket)
        write_log("TAMBAH_PAKET", f"Paket {nama} ({grup_nama}) berhasil dibuat", user=operator)
        return paket

    @staticmethod
    def update(paket_id, data, operator="system"):
        """Memperbarui data paket secara dinamis"""
        paket = PaketRepository.get_by_id(paket_id)

        # Validasi Nama jika diubah
        if "nama" in data:
            nama_baru = data["nama"].strip()
            if nama_baru != paket.nama:
                if PaketRepository.find_by_nama_exclude(nama_baru, paket_id):
                    raise ValueError(f"Nama paket '{nama_baru}' sudah dipakai paket lain")
                paket.nama = nama_baru

        # 🔍 Update Grup jika ada perubahan
        if "grup" in data:
            grup_obj = GrupRepository.find_by_nama(data["grup"])
            if not grup_obj: 
                raise ValueError("Grup yang dipilih tidak valid")
            paket.grup_id = grup_obj.id

        # Update field lainnya
        if "durasi_menit" in data:
            paket.durasi_menit = int(data["durasi_menit"])
        if "harga" in data:
            paket.harga = int(data["harga"])
        if "kadaluarsa_hari" in data:
            paket.kadaluarsa_hari = int(data["kadaluarsa_hari"])
        if "aktif" in data:
            paket.aktif = bool(data["aktif"])

        # 🟢 Simpan perubahan lewat Repo
        PaketRepository.commit()
        write_log("EDIT_PAKET", f"Data paket {paket.nama} diperbarui", user=operator)
        return paket

    @staticmethod
    def delete(paket_id, operator="system"):
        """Menghapus paket jika tidak sedang digunakan"""
        paket = PaketRepository.get_by_id(paket_id)

        # Proteksi: Jangan hapus paket yang masih nempel di sesi aktif
        if SesiRepository.get_aktif_by_paket(paket.id):
            raise ValueError("Paket ini sedang dipakai member/guest yang sedang main!")

        nama_paket = paket.nama
        PaketRepository.delete(paket)
        write_log("HAPUS_PAKET", f"Paket {nama_paket} dihapus permanen", user=operator)
        return True