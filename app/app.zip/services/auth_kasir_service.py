from app.repositories.user_repository import UserRepository
from app.utils.logger import write_log

class AuthKasirService:
    @staticmethod
    def login(username, password):
        if not username or not password:
            raise ValueError("Username dan password wajib diisi")
        user = UserRepository.get_by_username(username)
        if not user or not user.check_password(password):
            write_log("LOGIN_GAGAL", f"Username:{username} - Password salah")
            raise ValueError("Username atau password salah")
        write_log("LOGIN", f"Kasir:{username} ({user.nama_lengkap or ''}) login")
        return {
            "success": True,
            "user": user.to_dict(),
            "message": f"Selamat datang, {user.nama_lengkap or user.username}"
        }

    @staticmethod
    def logout(username):
        write_log("LOGOUT", f"Kasir {username} logout")
        return {"success": True, "message": "Logout berhasil"}

    @staticmethod
    def check_session(user_id, username, role):
        if user_id:
            return {"logged_in": True, "username": username, "role": role}
        return {"logged_in": False}