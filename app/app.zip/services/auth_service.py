# app/services/auth_service.py

from app.repositories.member_repository import MemberRepository
from app.repositories.pc_repository import PCRepository
from app.repositories.sesi_repository import SesiRepository
from app.models.sesi import Sesi
from app.models.base import now_local
from app.utils.logger import write_log
import secrets


class AuthService:

    @staticmethod
    def login(username, password, ip_address, mac_address):
        member = MemberRepository.get_by_username(username)
        if not member or not member.check_password(password):
            raise ValueError("Username atau password salah")

        pc = PCRepository.get_by_ip_and_mac(ip_address, mac_address)
        if not pc: raise ValueError("PC tidak terdaftar")

        # 🟢 Bandingkan ID, bukan teks
        if member.grup_id != pc.grup_id:
            raise ValueError(f"Member {member.grup.nama.upper()} dilarang di PC {pc.grup.nama.upper()}")

        if SesiRepository.get_aktif_by_pc(pc.id):
            raise ValueError(f"PC {pc.kode} sedang dipakai")

        member.cek_kadaluarsa()
        if member.waktu_tersimpan <= 0: raise ValueError("Waktu habis")

        sesi = Sesi(
            tipe="member", member_id=member.id, pc_id=pc.id, status="aktif",
            token_sesi=secrets.token_hex(32), waktu_mulai_sesi=now_local(),
            waktu_tersimpan_awal=member.waktu_tersimpan
        )
        # 🟢 Panggil Repo, bukan db.session
        SesiRepository.save(sesi) 

        write_log("LOGIN_MEMBER", f"{username} di PC {pc.kode}")
        return {
            "success": True, "waktu_tersimpan": member.waktu_tersimpan,
            "nama": member.nama_lengkap or member.username,
            "grup": member.grup.nama, "pc_kode": pc.kode,
            "token_sesi": sesi.token_sesi, "sesi_id": sesi.id
        }

    @staticmethod
    def logout(ip_address, mac_address, token_sesi=None):
        pc = PCRepository.get_by_ip_and_mac(ip_address, mac_address)
        if not pc: raise ValueError("PC tidak terdaftar")

        sesi = SesiRepository.get_aktif_by_pc(pc.id)
        if not sesi: raise ValueError("Tidak ada sesi aktif")
        if token_sesi and sesi.token_sesi != token_sesi: raise ValueError("Token salah")

        sesi.status = "selesai"
        sesi.selesai_pada = now_local()
        # 🟢 Pakai Commit dari Repo
        SesiRepository.commit() 
        return {"success": True}

    @staticmethod
    def get_status(ip_address, mac_address):
        pc = PCRepository.get_by_ip_and_mac(ip_address, mac_address)
        if not pc: raise ValueError("PC tidak terdaftar")

        sesi_aktif = SesiRepository.get_aktif_by_pc(pc.id)
        return {
            "pc_kode": pc.kode,
            "grup": pc.grup.nama if pc.grup else "reguler", # 🟢 Ambil nama
            "status": "dipakai" if sesi_aktif else "kosong",
            "sesi_id": sesi_aktif.id if sesi_aktif else None
        }