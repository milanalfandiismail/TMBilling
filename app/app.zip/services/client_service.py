# app/services/client_service.py

from app.models.base import now_local
from app.repositories.pc_repository import PCRepository
from app.repositories.sesi_repository import SesiRepository
from app.services.sesi_service import SesiService
from app.utils.logger import write_log


class ClientService:

    @staticmethod
    def identify(ip_address, mac_address):
        pc = PCRepository.get_by_ip(ip_address)
        if not pc:
            raise ValueError("IP tidak terdaftar")

        if not pc.mac_address:
            pc.mac_address = mac_address
            PCRepository.commit()
        elif pc.mac_address != mac_address:
            raise ValueError("MAC tidak cocok")

        return {"valid": True, "pc_kode": pc.kode, "grup": pc.grup.nama if pc.grup else "reguler"}


    @staticmethod
    def get_status(ip_address, mac_address):
        try:
            pc = PCRepository.get_by_ip_and_mac(ip_address, mac_address)
            if not pc:
                raise ValueError("PC tidak terdaftar")

            # Update last activity
            pc.last_activity = now_local()
            PCRepository.commit()


            # Ambil sesi aktif
            sesi = SesiRepository.get_aktif_by_pc(pc.id)
            if not sesi:
                return {
                    "status": "kosong",
                    "pc_kode": pc.kode
                }

            print(f"[DEBUG] LAST_ACTIVITY : {sesi.last_sync}")

            # Update last_sync
            try:
                sesi.last_sync = now_local()
                SesiRepository.commit()
            except:
                pass


            print(f"[DEBUG] LAST_ACTIVITY : {sesi.last_sync}")


            # Hitung sisa waktu
            try:
                sisa = SesiService.sync_waktu_member(sesi)
            except Exception as inner_e:
                write_log("CLIENT_STATUS_ERROR", f"Error sync waktu PC {pc.kode}: {inner_e}")
                sisa = 0

            if sisa <= 0:
                sesi.status = "selesai"
                sesi.selesai_pada = now_local()
                SesiRepository.commit()
                return {
                    "status": "lock",
                    "message": "Waktu habis",
                    "pc_kode": pc.kode
                }

            return {
                "status": "aktif",
                "sisa_waktu": sisa,
                "nama": sesi.member.nama_lengkap if sesi.member else sesi.nama_guest or "Guest",
                "grup": pc.grup.nama if pc.grup else "reguler",  # ← pakai .nama
                "pc_kode": pc.kode
            }

        except Exception as e:
            write_log("CLIENT_STATUS_CRASH", f"Error fatal di get_status dari {ip_address}: {e}")
            return {"status": "error", "message": "Server error"}

    @staticmethod
    def tutup_sesi(ip_address: str, mac_address: str):
        try:
            pc = PCRepository.get_by_ip_and_mac(ip_address, mac_address)
            if not pc:
                raise ValueError("PC tidak terdaftar")

            sesi = SesiRepository.get_aktif_by_pc(pc.id)
            if sesi:
                SesiService.tutup_sesi(sesi.id, operator="client")

            pc.last_activity = now_local()
            PCRepository.commit()

            return {"success": True, "message": "Sesi ditutup"}
        except Exception as e:
            write_log("CLIENT_TUTUP_ERROR", f"Error tutup sesi {ip_address}: {e}")
            return {"success": False, "message": "Gagal menutup sesi"}