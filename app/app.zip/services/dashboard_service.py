# app/services/dashboard_service.py
from app.services.sesi_service import SesiService
from app.services.pc_service import PCService
from app.utils.logger import write_log
from app.models.base import now_local

class DashboardService:
    @staticmethod
    def get_dashboard_data(username):
        write_log("ACCESS_DASHBOARD", f"Kasir {username} mengakses dashboard", user=username)
        return {"success": True}

    @staticmethod
    def get_pc_list():
        SesiService.cleanup_expired()
        pcs = PCService.get_all(aktif_only=True)
        pc_list = []
        by_grup = {}
        now = now_local()

        for pc in pcs:
            pc_dict = pc.to_dict()
            
            # Cek Online (5 detik)
            online = False
            if pc.last_activity:
                if (now - pc.last_activity).total_seconds() < 5:
                    online = True
            pc_dict['online'] = online
            
            # Sesi Detail
            sesi_aktif = pc.sesi_aktif
            if sesi_aktif:
                pc_dict['sesi_detail'] = sesi_aktif.to_dict()
                pc_dict['status'] = "terpakai"
            else:
                pc_dict['sesi_detail'] = None
                pc_dict['status'] = "kosong"
            
            g_nama = pc.grup.nama if pc.grup else "reguler"
            by_grup.setdefault(g_nama, []).append(pc_dict)
            pc_list.append(pc_dict) # 🟢 PERBAIKAN: Hanya append sekali
        
        return {"pc_list": pc_list, "by_grup": by_grup}