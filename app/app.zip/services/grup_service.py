# app/services/grup_service.py
from app.models.grup import Grup
from app.repositories.grup_repository import GrupRepository
from app.utils.logger import write_log

class GrupService:
    @staticmethod
    def get_all():
        return GrupRepository.get_all()

    @staticmethod
    def create(data, operator="system"):
        nama = data.get("nama", "").strip().lower()
        if GrupRepository.find_by_nama(nama): raise ValueError("Grup sudah ada")
        grup = Grup(nama=nama)
        GrupRepository.save(grup) 
        write_log("TAMBAH_GRUP", f"Grup baru: {nama}", user=operator)
        return grup

    @staticmethod
    def delete(grup_id, operator="system"):
        grup = GrupRepository.get_by_id(grup_id)
        if not grup: raise ValueError("Grup tidak ditemukan")
        
        # 🟢 PROTEKSI: Cek relasi backref
        if len(grup.member_list) > 0:
            raise ValueError(f"Grup {grup.nama} tidak bisa dihapus karena masih ada Member")
        if len(grup.pc_list) > 0:
            raise ValueError(f"Grup {grup.nama} masih digunakan oleh beberapa PC")
        if len(grup.paket_list) > 0:
            raise ValueError(f"Grup {grup.nama} masih memiliki paket")
        
        nama_lama = grup.nama
        GrupRepository.delete(grup)
        write_log("HAPUS_GRUP", f"Grup {nama_lama} dihapus", user=operator)
        return True