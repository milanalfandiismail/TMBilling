# app/services/member_service.py

from app.models.member import Member
from app.repositories.member_repository import MemberRepository
from app.repositories.sesi_repository import SesiRepository
from app.repositories.grup_repository import GrupRepository
from app.utils.logger import write_log


class MemberService:

    @staticmethod
    def get_all():
        return MemberRepository.get_all()

    @staticmethod
    def get_by_id(member_id):
        return MemberRepository.get_by_id(member_id)

    @staticmethod
    def get_by_username(username):
        return MemberRepository.get_by_username(username)

    @staticmethod
    def create(data, operator="system"):
        username = data.get("username", "").strip().lower()
        if not username: raise ValueError("Username wajib diisi")
        if MemberRepository.find_by_username(username): raise ValueError("Username sudah ada")

        # 🔍 Cari ID Grup
        grup_nama = data.get("grup", "reguler")
        grup_obj = GrupRepository.find_by_nama(grup_nama)
        if not grup_obj: raise ValueError("Grup member tidak valid")

        member = Member(
            username=username,
            nama_lengkap=data.get("nama_lengkap"),
            email=data.get("email"),
            no_hp=data.get("no_hp"),
            grup_id=grup_obj.id, # <--- Simpan ID relasi
            waktu_tersimpan=0
        )
        member.set_password(data.get("password", "123456"))
        MemberRepository.save(member)
        write_log("TAMBAH_MEMBER", f"Member {username} ({grup_nama}) dibuat", user=operator)
        return member

    @staticmethod
    def update(member_id, data, operator="system"):
        member = MemberRepository.get_by_id(member_id)
        if not member: raise ValueError("Member tidak ditemukan")

        if "grup" in data:
            grup_obj = GrupRepository.find_by_nama(data["grup"])
            if not grup_obj: raise ValueError("Grup tidak valid")
            member.grup_id = grup_obj.id

        member.nama_lengkap = data.get("nama_lengkap", member.nama_lengkap)
        member.email = data.get("email", member.email)
        
        MemberRepository.commit()
        write_log("EDIT_MEMBER", f"Data member {member.username} diperbarui", user=operator)
        return member

    @staticmethod
    def delete(member_id, operator="system"):
        member = MemberRepository.get_by_id(member_id)
        if SesiRepository.get_aktif_by_member(member.id):
            raise ValueError("Member sedang bermain, tidak bisa dihapus")
        
        MemberRepository.delete(member)
        write_log("DELETE_MEMBER", f"Member:{member.username} dihapus permanen", user=operator)
        return member

    @staticmethod
    def tambah_waktu(member_id, paket, operator="system"):
        member = MemberRepository.get_by_id(member_id)
        if paket.grup_id != member.grup_id:
            raise ValueError(f"Grup tidak cocok")
        
        member.tambah_waktu(paket.durasi_menit, paket.kadaluarsa_hari)
        # 🟢 PAKAI REPO COMMIT
        MemberRepository.commit() 
        write_log("TAMBAH_WAKTU", f"Member:{member.username} | +{paket.durasi_menit}m", user=operator)
        return member