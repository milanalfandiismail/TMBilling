# app/services/pc_service.py

from app.models.pc import PC
from app.repositories.pc_repository import PCRepository
from app.repositories.sesi_repository import SesiRepository
from app.repositories.grup_repository import GrupRepository
from app.utils.logger import write_log

class PCService:

    @staticmethod
    def get_all(aktif_only=False):
        """Mengambil daftar PC, bukan paket!"""
        return PCRepository.get_all(aktif_only)

    @staticmethod
    def get_by_id(pc_id):
        """Mencari PC berdasarkan ID"""
        return PCRepository.get_by_id(pc_id)

    @staticmethod
    def get_by_kode(kode):
        """Mencari PC berdasarkan Kode"""
        return PCRepository.get_by_kode(kode)

    @staticmethod
    def group_by_grup(pcs):
        """Mengelompokkan PC berdasarkan nama grup relasinya"""
        result = {}
        for pc in pcs:
            # Ambil nama dari relasi Grup
            g = pc.grup.nama if pc.grup else "reguler"
            if g not in result:
                result[g] = []
            result[g].append(pc.to_dict())
        return result

    @staticmethod
    def create(data, operator="system"):
        """Mendaftarkan PC baru ke sistem"""
        kode = data.get("kode", "").strip().upper()
        if not kode: 
            raise ValueError("Kode PC wajib diisi")
        
        if PCRepository.get_by_kode(kode): 
            raise ValueError(f"PC dengan kode {kode} sudah ada")

        # 🔍 Cari objek grup dari nama (string)
        grup_nama = data.get("grup", "reguler")
        grup_obj = GrupRepository.find_by_nama(grup_nama)
        if not grup_obj:
            raise ValueError(f"Grup '{grup_nama}' tidak ditemukan. Buat dulu di menu Grup.")

        # Buat objek PC sesuai kolom di model
        pc = PC(
            kode=kode,
            nama=data.get("nama") or kode,
            ip_address=data.get("ip_address"),
            mac_address=data.get("mac_address"),
            grup_id=grup_obj.id,
        )
        
        PCRepository.save(pc) # Simpan lewat Repo
        write_log("TAMBAH_PC", f"PC {kode} ({grup_nama}) didaftarkan", user=operator)
        return pc

    @staticmethod
    def update(pc_id, data, operator="system"):
        """Memperbarui data PC"""
        pc = PCRepository.get_by_id(pc_id)
        
        if "grup" in data:
            grup_obj = GrupRepository.find_by_nama(data["grup"])
            if not grup_obj: 
                raise ValueError("Grup tidak valid")
            pc.grup_id = grup_obj.id # Update relasi ID
        
        pc.nama = data.get("nama", pc.nama)
        pc.ip_address = data.get("ip_address", pc.ip_address)
        pc.mac_address = data.get("mac_address", pc.mac_address)
        
        PCRepository.commit() # Simpan perubahan
        write_log("EDIT_PC", f"Data PC {pc.kode} diperbarui", user=operator)
        return pc

    @staticmethod
    def delete(pc_id, operator="system"):
        pc = PCRepository.get_by_id(pc_id)
        if not pc:
            raise ValueError("PC tidak ditemukan")

        PCRepository.delete(pc)
        write_log("HAPUS_PC", f"PC:{pc.kode} dihapus permanen", user=operator)
        return {"success": True, "message": f"PC {pc.kode} berhasil dihapus"}

    @staticmethod
    def create_batch(data, operator="system"):
        """Menambah banyak PC sekaligus (Bulk)"""
        prefix = data.get("prefix", "PC").upper()
        start, end = int(data.get("start", 1)), int(data.get("end", 5))
        grup_nama = data.get("grup", "reguler").lower()
        
        grup_obj = GrupRepository.find_by_nama(grup_nama)
        if not grup_obj: 
            raise ValueError(f"Grup {grup_nama} belum ada")

        pc_to_save = []
        added, errors = [], []
        
        for i in range(start, end + 1):
            kode = f"{prefix}-{i:02d}"
            if PCRepository.find_by_kode(kode):
                errors.append(f"{kode} duplikat")
                continue
            
            pc = PC(
                kode=kode, 
                nama=f"{prefix} {i}", 
                grup_id=grup_obj.id,
                aktif=True
            )
            pc_to_save.append(pc)
            added.append(kode)
        
        if pc_to_save:
            # 🟢 Pastikan fungsi save_batch ada di PCRepository!
            PCRepository.save_batch(pc_to_save) 
            write_log("BATCH_PC", f"Tambah {len(added)} PC", user=operator)
            
        return {"added": added, "errors": errors}

    @staticmethod
    def get_status_summary():
        """Menghitung ringkasan status PC untuk dashboard"""
        all_pc = PCRepository.get_all(aktif_only=True)
        total = len(all_pc)
        terpakai = sum(1 for pc in all_pc if pc.sesi_aktif)
        return {"total": total, "terpakai": terpakai, "kosong": total - terpakai}