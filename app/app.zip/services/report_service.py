# app/services/report_service.py

from app.models.base import now_local
from app.repositories.transaksi_repository import TransaksiRepository
from app.repositories.sesi_repository import SesiRepository
from app.utils.logger import read_logs, write_log, clear_logs
from datetime import datetime

class ReportService:

    @staticmethod
    def get_laporan_harian():
        """Mengambil ringkasan pendapatan dan sesi hari ini"""
        hari_ini = now_local().date()
        total = TransaksiRepository.get_total_pendapatan_hari_ini(hari_ini)
        
        # Menggunakan repository untuk menghitung total sesi
        total_sesi = SesiRepository.count_by_date(hari_ini)
        aktif_sekarang = len(SesiRepository.get_all_aktif())

        return {
            "tanggal": str(hari_ini),
            "total_pendapatan": int(total),
            "total_sesi": total_sesi,
            "sesi_aktif": aktif_sekarang
        }

    @staticmethod
    def get_system_logs(limit=500, filter_text=""):
        """Mengambil log sistem melalui utility logger"""
        logs = read_logs(limit, filter_text if filter_text else None)
        return {"logs": logs, "total": len(logs)}

    @staticmethod
    def clear_system_logs(operator="system"):
        """Membersihkan file log dan mencatat pelakunya"""
        if clear_logs():
            # Logging aksi pembersihan dipusatkan di sini
            write_log("CLEAR_LOG", f"Log dibersihkan", user=operator)
            return True
        return False

    @staticmethod
    def prepare_export_data(filter_text=""):
        """Menyiapkan konten teks untuk diekspor"""
        logs = read_logs(5000, filter_text if filter_text else None)
        content = "\n".join(logs)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        return content, timestamp