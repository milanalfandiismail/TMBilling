# app/routes/client_routes.py

from flask import Blueprint, request, jsonify, current_app
from app.services.client_service import ClientService
from app.utils.logger import write_log
from functools import wraps

client_bp = Blueprint("client", __name__)


def api_key_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        api_key = request.headers.get("X-Client-Key")
        expected_key = current_app.config.get("CLIENT_API_KEY", "warnet-client-key-2024")
        if not api_key or api_key != expected_key:
            write_log("API_KEY_GAGAL", f"Invalid API Key from {request.remote_addr}")
            return jsonify({"error": "Akses ditolak. API Key tidak valid"}), 401
        return f(*args, **kwargs)
    return decorated


@client_bp.route("/identify", methods=["POST"])
@api_key_required
def identify():
    data = request.get_json() or {}
    try:
        result = ClientService.identify(
            ip_address=data.get("ip_address"),
            mac_address=data.get("mac_address", "").upper().strip()
        )
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"valid": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"valid": False, "error": f"Terjadi kesalahan: {str(e)}"}), 500


@client_bp.route("/status", methods=["POST"])
@api_key_required
def status():
    data = request.get_json() or {}
    try:
        result = ClientService.get_status(
            ip_address=data.get("ip_address"),
            mac_address=data.get("mac_address", "").upper().strip()
        )
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Terjadi kesalahan: {str(e)}"}), 500


@client_bp.route("/selesai", methods=["POST"])
@api_key_required
def selesai():
    data = request.get_json() or {}
    try:
        result = ClientService.tutup_sesi(
            ip_address=data.get("ip_address"),
            mac_address=data.get("mac_address", "").upper().strip()
        )
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Terjadi kesalahan: {str(e)}"}), 500