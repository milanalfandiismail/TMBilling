# app/routes/pc_routes.py

from flask import Blueprint, request, jsonify, session
from app.routes.auth_kasir_routes import login_required
from app.services.pc_service import PCService

pc_bp = Blueprint("pc", __name__)

@pc_bp.route("/pc", methods=["GET"])
@login_required
def list_pc():
    """Endpoint untuk mendapatkan daftar PC"""
    try:
        pcs = PCService.get_all()
        grouped = PCService.group_by_grup(pcs)
        return jsonify({
            "pc_list": [pc.to_dict() for pc in pcs],
            "grouped": grouped
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pc_bp.route("/pc", methods=["POST"])
@login_required
def tambah_pc():
    """Endpoint untuk tambah satu PC"""
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        
        # Panggil Service dengan menyertakan operator
        pc = PCService.create(data, operator=kasir)

        return jsonify({
            "success": True,
            "message": "PC ditambahkan",
            "pc": pc.to_dict()
        }), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pc_bp.route("/pc/<int:pc_id>", methods=["PUT"])
@login_required
def edit_pc(pc_id):
    """Endpoint untuk edit data PC"""
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        
        pc = PCService.update(pc_id, data, operator=kasir)

        return jsonify({
            "success": True,
            "message": "PC berhasil diupdate",
            "pc": pc.to_dict()
        }), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pc_bp.route("/pc/<int:pc_id>", methods=["DELETE"])
@login_required
def hapus_pc(pc_id):
    """Endpoint untuk hapus PC"""
    try:
        kasir = session.get("kasir_username", "kasir")
        result = PCService.delete(pc_id, operator=kasir)

        return jsonify({"success": True, "message": result['message']}), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pc_bp.route("/pc/batch", methods=["POST"])
@login_required
def tambah_batch():
    """Endpoint untuk tambah PC masal"""
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        
        result = PCService.create_batch(data, operator=kasir)

        return jsonify({
            "success": True,
            "added": len(result["added"]),
            "pc_list": result["added"],
            "errors": result["errors"]
        }), 201
    except Exception as e:
        return jsonify({"error": str(e)}), 500