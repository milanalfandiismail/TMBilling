from flask import Blueprint, request, jsonify
from app.services.auth_service import AuthService

auth_bp = Blueprint("auth", __name__)

@auth_bp.route("/login", methods=["POST"])
def login():
    """Login member dari PC client - 100% Clean Layer"""
    data = request.get_json() or {}
    try:
        # Gunakan AuthService.login yang sudah abang buat di auth_service.py
        result = AuthService.login(
            username=data.get("username", ""),
            password=data.get("password", ""),
            ip_address=data.get("ip_address"),
            mac_address=data.get("mac_address", "").upper().strip()
        )
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Server Error: {str(e)}"}), 500