# app/routes/dashboard_routes.py
from flask import Blueprint, request, jsonify, render_template, redirect, session, url_for
from app.routes.auth_kasir_routes import login_required, login_required_html
from app.services.dashboard_service import DashboardService

# Blueprint tetap sama
dashboard_bp = Blueprint("dashboard", __name__)

# 1. ROUTE HALAMAN UTAMA (HTML)
# Akses: http://ip:5000/api/dashboard/
@dashboard_bp.route("/", methods=["GET"])
@login_required_html
def dashboard():
    # Ini buat buka halaman index.html
    return render_template("kasir/index.html")

# 2. ROUTE HALAMAN LOGIN (HTML)
# Akses: http://ip:5000/api/dashboard/login
@dashboard_bp.route("/login", methods=["GET"])
def login_page():
    if session.get("kasir_id"):
        return redirect(url_for('dashboard.dashboard'))
    return render_template("kasir/login.html")

# 3. ROUTE DATA PC (JSON API)
# Akses: http://ip:5000/api/dashboard/pc
@dashboard_bp.route("/api/pc", methods=["GET"])
@login_required
def list_pc_api():
    try:
        # Panggil service untuk ambil data grid PC
        result = DashboardService.get_pc_list() 
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500