# app/routes/grup_routes.py
from flask import Blueprint, request, jsonify, session
from app.routes.auth_kasir_routes import login_required
from app.services.grup_service import GrupService

grup_bp = Blueprint("grup", __name__)

@grup_bp.route("/", methods=["GET"])
@login_required
def list_grup():
    try:
        grup_list = GrupService.get_all()
        # 🟢 PERBAIKAN: Kirim list of objects, bukan list of strings
        # JavaScript butuh 'g.id' dan 'g.nama' untuk tombol hapus dan tabel
        return jsonify({
            "grup": [
                {
                    "id": g.id, 
                    "nama": g.nama, 
                    "keterangan": g.keterangan
                } for g in grup_list
            ]
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@grup_bp.route("/", methods=["POST"])
@login_required
def tambah_grup():
    try:
        kasir = session.get("kasir_username", "kasir")
        grup = GrupService.create(request.get_json() or {}, operator=kasir)
        return jsonify({"success": True, "message": f"Grup {grup.nama} dibuat"}), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@grup_bp.route("/<int:grup_id>", methods=["DELETE"])
@login_required
def hapus_grup(grup_id):
    try:
        kasir = session.get("kasir_username", "kasir")
        GrupService.delete(grup_id, operator=kasir)
        return jsonify({"success": True, "message": "Grup berhasil dihapus"}), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500