# app/routes/paket_routes.py

from flask import Blueprint, request, jsonify, session
from app.routes.auth_kasir_routes import login_required
from app.services.paket_service import PaketService

paket_bp = Blueprint("paket", __name__)


@paket_bp.route("/", methods=["GET"])
@login_required
def list_paket():
    try:
        aktif_only = request.args.get('aktif', 'false').lower() == 'true'
        grup_nama = request.args.get('grup', None)
        paket = PaketService.get_all(aktif_only, grup_nama)
        return jsonify({"paket": [p.to_dict() for p in paket]}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@paket_bp.route("/", methods=["POST"])
@login_required
def tambah_paket():
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        
        # Kirim nama kasir sebagai 'operator' ke Service
        paket = PaketService.create(data, operator=kasir)
        
        return jsonify({"success": True, "message": "Berhasil"}), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@paket_bp.route("/<int:paket_id>", methods=["PUT"])
@login_required
def edit_paket(paket_id):
    try:
        data = request.get_json() or {}

        kasir = session.get("kasir_username", "kasir") # Ambil kasir
        
        # Teruskan ke service dengan operator
        paket = PaketService.update(paket_id, data, operator=kasir)

        return jsonify({
            "success": True,
            "message": f"Paket '{paket.nama}' berhasil diupdate",
            "paket": paket.to_dict()
        }), 200

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@paket_bp.route("/<int:paket_id>", methods=["DELETE"])
@login_required
def hapus_paket(paket_id):
    try:
        
        kasir = session.get("kasir_username", "kasir") # Ambil kasir
        
        PaketService.delete(paket_id, operator=kasir)

        return jsonify({"success": True, "message": "Paket berhasil dihapus"}), 200

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500