# app/routes/blackout_routes.py
from flask import Blueprint, jsonify, request, session
from app.routes.auth_kasir_routes import login_required
from app.services.blackout_service import BlackoutService

blackout_bp = Blueprint("blackout", __name__)


@blackout_bp.route("/deteksi", methods=["POST"])
@login_required
def deteksi():
    """Kasir klik 'Deteksi Blackout' — scan sesi aktif yang last_sync sudah lama"""
    try:
        data = request.get_json(silent=True) or {}
        threshold = data.get("threshold_menit", None)
        count = BlackoutService.deteksi(threshold)
        return jsonify({
            "success": True,
            "total": count,
            "message": f"{count} sesi terdeteksi blackout" if count > 0 else "Tidak ada sesi yang terdeteksi blackout"
        }), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@blackout_bp.route("/list", methods=["GET"])
@login_required
def list_audit():
    """Daftar sesi blackout, opsional filter tanggal"""
    try:
        selected_date = request.args.get("date")
        sesi_list = BlackoutService.get_audit_list(selected_date)
        return jsonify({
            "data": [s.to_dict_audit() for s in sesi_list],
            "total": len(sesi_list)
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@blackout_bp.route("/dates", methods=["GET"])
@login_required
def get_dates():
    """Daftar tanggal yang punya audit blackout"""
    try:
        dates = BlackoutService.get_audit_dates()
        return jsonify({"dates": dates}), 200
    except Exception as e:
        return jsonify({"dates": []}), 200


@blackout_bp.route("/resolve/member/<int:sesi_id>", methods=["POST"])
@login_required
def resolve_member(sesi_id):
    """Kasir kembalikan saldo member"""
    try:
        kasir = session.get("kasir_username", "kasir")
        result = BlackoutService.resolve_member(sesi_id, operator=kasir)
        return jsonify({
            "success": True,
            "message": f"Saldo {result['saldo_kembali']} menit dikembalikan ke {result['username']}"
        }), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@blackout_bp.route("/resolve/guest/lanjut/<int:sesi_id>", methods=["POST"])
@login_required
def resolve_guest_lanjut(sesi_id):
    """Kasir lanjutkan sesi guest di PC baru"""
    try:
        kasir = session.get("kasir_username", "kasir")
        data = request.get_json(silent=True) or {}
        pc_baru_id = data.get("pc_baru_id")
        if not pc_baru_id:
            return jsonify({"success": False, "error": "pc_baru_id wajib diisi"}), 400

        result = BlackoutService.resolve_guest_lanjut(sesi_id, int(pc_baru_id), operator=kasir)
        return jsonify({
            "success": True,
            "message": f"Guest {result['nama_guest']} dilanjutkan di {result['pc_baru']} ({result['sisa_menit']} menit)"
        }), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@blackout_bp.route("/resolve/guest/tutup/<int:sesi_id>", methods=["POST"])
@login_required
def resolve_guest_tutup(sesi_id):
    """Kasir tutup sesi guest tanpa kompensasi"""
    try:
        kasir = session.get("kasir_username", "kasir")
        result = BlackoutService.resolve_guest_tutup(sesi_id, operator=kasir)
        return jsonify({
            "success": True,
            "message": f"Sesi guest {result['nama_guest']} ditutup"
        }), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@blackout_bp.route("/resolve/guest/sama/<int:sesi_id>", methods=["POST"])
@login_required
def resolve_guest_sama(sesi_id):
    try:
        kasir = session.get("kasir_username", "kasir")
        result = BlackoutService.resolve_guest_sama(sesi_id, operator=kasir)
        return jsonify({
            "success": True,
            "message": f"Guest {result['nama_guest']} dilanjutkan di PC {result['pc']} ({result['sisa_menit']} menit)"
        }), 200
    except ValueError as e:
        return jsonify({"success": False, "error": str(e)}), 400
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@blackout_bp.route("/force-all-and-detect", methods=["POST"])
@login_required
def force_all_and_detect():
    try:
        kasir = session.get("kasir_username", "kasir")
        result = BlackoutService.force_all_and_detect(operator=kasir)
        return jsonify({
            "success": True,
            "tutup": result["tutup"],
            "deteksi": result["deteksi"],
            "message": f"{result['tutup']} sesi ditutup, {result['deteksi']} sesi masuk blackout"
        }), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@blackout_bp.route("/clear", methods=["POST"])
@login_required
def clear_audit():
    """Hapus record audit yang sudah resolved berdasarkan tanggal"""
    try:
        kasir = session.get("kasir_username", "kasir")
        data = request.get_json(silent=True) or {}
        selected_date = data.get("date")
        if not selected_date:
            return jsonify({"success": False, "error": "Tanggal harus diisi"}), 400
        deleted = BlackoutService.clear_resolved(selected_date, operator=kasir)
        return jsonify({
            "success": True,
            "message": f"{deleted} record audit pada {selected_date} dihapus"
        }), 200
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


