# app/routes/report_routes.py

from flask import Blueprint, request, jsonify, Response, session
from app.routes.auth_kasir_routes import login_required
from app.services.report_service import ReportService

report_bp = Blueprint("report", __name__)

@report_bp.route("/laporan-harian", methods=["GET"])
@login_required
def laporan_harian():
    """Endpoint ringkasan laporan harian"""
    try:
        laporan = ReportService.get_laporan_harian()
        return jsonify(laporan), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@report_bp.route("/log", methods=["GET"])
@login_required
def get_logs():
    """Endpoint melihat log sistem"""
    try:
        filter_text = request.args.get("filter", "")
        limit = request.args.get("limit", 500, type=int)
        
        # Delegasikan pengambilan data ke Service
        result = ReportService.get_system_logs(limit, filter_text)
        return jsonify(result), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@report_bp.route("/log/clear", methods=["POST"])
@login_required
def clear_logs_endpoint():
    """Endpoint membersihkan log"""
    try:
        kasir = session.get("kasir_username", "kasir")
        # Service yang akan menghapus log dan mencatat audit trail
        if ReportService.clear_system_logs(operator=kasir):
            return jsonify({"success": True, "message": "Log dibersihkan"}), 200
        return jsonify({"error": "Gagal membersihkan log"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@report_bp.route("/log/export", methods=["GET"])
@login_required
def export_logs():
    """Endpoint ekspor log ke file .txt"""
    try:
        filter_text = request.args.get("filter", "")
        # Ambil data konten dari Service
        content, timestamp = ReportService.prepare_export_data(filter_text)
        
        return Response(
            content,
            mimetype="text/plain",
            headers={"Content-Disposition": f"attachment;filename=warnet_log_{timestamp}.txt"}
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500
@report_bp.route("/blackout-log", methods=["GET"])
@login_required
def blackout_log():
    """Ambil log blackout recovery terakhir (SERVER_RESTART, BLACKOUT_MEMBER, BLACKOUT_GUEST)"""
    try:
        result = ReportService.get_system_logs(limit=200, filter_text="BLACKOUT")
        restart = ReportService.get_system_logs(limit=10, filter_text="SERVER_RESTART")
        return jsonify({
            "blackout_logs": result["logs"],
            "restart_logs": restart["logs"]
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
