# app/routes/auth_kasir_routes.py

from flask import Blueprint, request, jsonify, session, redirect
from app.services.auth_kasir_service import AuthKasirService
from functools import wraps

auth_kasir_bp = Blueprint("auth_kasir", __name__)


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("kasir_id"):
            return jsonify({"error": "Silakan login terlebih dahulu"}), 401
        return f(*args, **kwargs)
    return decorated_function


def login_required_html(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("kasir_id"):
            return redirect("/kasir/login")
        return f(*args, **kwargs)
    return decorated_function


@auth_kasir_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    username = data.get("username", "").strip()
    password = data.get("password", "")

    try:
        result = AuthKasirService.login(username, password)

        # Simpan ke session
        session["kasir_id"] = result["user"]["id"]
        session["kasir_username"] = result["user"]["username"]
        session["kasir_role"] = result["user"]["role"]

        return jsonify(result), 200

    except ValueError as e:
        return jsonify({"error": str(e)}), 401
    except Exception as e:
        return jsonify({"error": f"Terjadi kesalahan: {str(e)}"}), 500


@auth_kasir_bp.route("/logout", methods=["POST"])
@login_required  # <-- TAMBAHKAN INI
def logout():
    username = session.get("kasir_username", "kasir")

    try:
        result = AuthKasirService.logout(username)

        # Hapus session
        session.pop("kasir_id", None)
        session.pop("kasir_username", None)
        session.pop("kasir_role", None)

        return jsonify(result), 200

    except Exception as e:
        return jsonify({"error": f"Terjadi kesalahan: {str(e)}"}), 500


@auth_kasir_bp.route("/check", methods=["GET"])
def check_session():
    result = AuthKasirService.check_session(
        user_id=session.get("kasir_id"),
        username=session.get("kasir_username"),
        role=session.get("kasir_role")
    )
    return jsonify(result), 200