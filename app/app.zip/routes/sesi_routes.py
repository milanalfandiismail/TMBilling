# app/routes/sesi_routes.py

from flask import Blueprint, request, jsonify, session
from app.routes.auth_kasir_routes import login_required
from app.services.sesi_service import SesiService
from app.services.paket_service import PaketService

sesi_bp = Blueprint("sesi", __name__)

@sesi_bp.route("/buka-guest", methods=["POST"])
@login_required
def buka_guest():
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        
        sesi = SesiService.buka_guest(
            pc_kode=data.get("pc_kode"),
            paket_id=data.get("paket_id"),
            nama_guest=data.get("nama_guest", "Guest"),
            operator=kasir
        )
        return jsonify({
            "success": True, "message": "Sesi guest dibuka",
            "sesi_id": sesi.id, "token_sesi": sesi.token_sesi,
            "sisa_menit": sesi.sisa_menit()
        }), 201
    except ValueError as e: return jsonify({"error": str(e)}), 400
    except Exception as e: return jsonify({"error": str(e)}), 500

@sesi_bp.route("/buka-member", methods=["POST"])
@login_required
def buka_member():
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        
        sesi = SesiService.buka_member(
            pc_kode=data.get("pc_kode"),
            username=data.get("username"),
            operator=kasir
        )
        return jsonify({
            "success": True, "message": f"Sesi member {sesi.member.username} dibuka",
            "sesi_id": sesi.id, "token_sesi": sesi.token_sesi,
            "waktu_tersimpan": sesi.member.waktu_tersimpan
        }), 201
    except ValueError as e: return jsonify({"error": str(e)}), 400
    except Exception as e: return jsonify({"error": str(e)}), 500

@sesi_bp.route("/tambah-waktu-sesi/<int:sesi_id>", methods=["POST"])
@login_required
def tambah_waktu_sesi(sesi_id):
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        paket = PaketService.get_by_id(data.get("paket_id"))
        
        result = SesiService.tambah_waktu_sesi(sesi_id, paket, operator=kasir)
        return jsonify({
            "success": True, "message": f"Ditambahkan {paket.durasi_menit} menit",
            "tipe": result["tipe"],
            "waktu_baru": result.get("waktu_tersimpan") or result.get("sisa_menit")
        }), 200
    except ValueError as e: return jsonify({"error": str(e)}), 400
    except Exception as e: return jsonify({"error": str(e)}), 500

@sesi_bp.route("/tutup/<int:sesi_id>", methods=["POST"])
@login_required
def tutup_sesi(sesi_id):
    try:
        kasir = session.get("kasir_username", "kasir")
        SesiService.tutup_sesi(sesi_id, operator=kasir)
        return jsonify({"success": True, "message": "Sesi ditutup"}), 200
    except ValueError as e: return jsonify({"error": str(e)}), 400
    except Exception as e: return jsonify({"error": str(e)}), 500

@sesi_bp.route("/pindah-pc/<int:sesi_id>", methods=["POST"])
@login_required
def pindah_pc(sesi_id):
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        result = SesiService.pindah_pc(sesi_id, data.get("pc_kode_baru"), operator=kasir)
        return jsonify({
            "success": True, "message": f"Dipindah ke {result['pc_baru']}",
            "pc_lama": result['pc_lama'], "pc_baru": result['pc_baru']
        }), 200
    except ValueError as e: return jsonify({"error": str(e)}), 400
    except Exception as e: return jsonify({"error": str(e)}), 500

@sesi_bp.route("/sesi/<int:sesi_id>", methods=["GET"])
@login_required
def get_sesi(sesi_id):
    try:
        result = SesiService.get_detail(sesi_id)
        return jsonify(result), 200
    except ValueError as e: return jsonify({"error": str(e)}), 404
    except Exception as e: return jsonify({"error": str(e)}), 500