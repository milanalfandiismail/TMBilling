# app/routes/member_routes.py

from flask import Blueprint, request, jsonify, session
from app.routes.auth_kasir_routes import login_required
from app.services.member_service import MemberService
from app.services.paket_service import PaketService

member_bp = Blueprint("member", __name__)


@member_bp.route("/member", methods=["GET"])
@login_required
def list_member():
    try:
        members = MemberService.get_all()
        return jsonify({"members": [m.to_dict() for m in members]}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@member_bp.route("/member/<int:member_id>", methods=["GET"])
@login_required
def get_member_detail(member_id):
    try:
        member = MemberService.get_by_id(member_id)
        if not member:
            return jsonify({"error": "Member tidak ditemukan"}), 404
        return jsonify({"member": member.to_dict()}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@member_bp.route("/member", methods=["POST"])
@login_required
def tambah_member():
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir") # Ambil identitas kasir
        
        # Kirim data dan operator ke Service
        member = MemberService.create(data, operator=kasir)

        return jsonify({
            "success": True, 
            "message": f"Member '{member.username}' berhasil ditambahkan"
        }), 201
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@member_bp.route("/member/<int:member_id>", methods=["PUT"])
@login_required
def edit_member(member_id):
    try:
        data = request.get_json() or {}
        
        # 1. Ambil nama kasir dari session
        kasir = session.get("kasir_username", "kasir") 

        # 2. Kirim data dan nama kasir ke Service
        member = MemberService.update(member_id, data, operator=kasir)

        # 🔴 JANGAN tulis write_log di sini lagi (sudah diwakili Service)

        return jsonify({
            "success": True,
            "message": f"Member '{member.username}' berhasil diupdate",
            "member": member.to_dict()
        }), 200

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@member_bp.route("/member/<int:member_id>", methods=["DELETE"])
@login_required
def delete_member(member_id):
    try:
        kasir = session.get("kasir_username", "kasir")
        MemberService.delete(member_id, operator=kasir)
        return jsonify({"success": True, "message": "Member berhasil dihapus"}), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@member_bp.route("/tambah-waktu", methods=["POST"])
@login_required
def tambah_waktu():
    try:
        data = request.get_json() or {}
        kasir = session.get("kasir_username", "kasir")
        
        paket = PaketService.get_by_id(data.get("paket_id"))
        member = MemberService.tambah_waktu(data.get("member_id"), paket, operator=kasir)

        return jsonify({"success": True, "message": "Waktu berhasil ditambah"}), 200
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500