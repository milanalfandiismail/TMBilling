from app.routes.auth_routes import auth_bp
from app.routes.auth_kasir_routes import auth_kasir_bp
from app.routes.client_routes import client_bp
from app.routes.dashboard_routes import dashboard_bp
from app.routes.member_routes import member_bp
from app.routes.paket_routes import paket_bp
from app.routes.pc_routes import pc_bp
from app.routes.report_routes import report_bp
from app.routes.sesi_routes import sesi_bp
from app.routes.grup_routes import grup_bp
from app.routes.blackout_routes import blackout_bp
__all__ = [
    'auth_bp', 'auth_kasir_bp', 'client_bp', 'dashboard_bp',
    'member_bp', 'paket_bp', 'pc_bp', 'report_bp', 'sesi_bp',
    'grup_bp',
    'blackout_bp'
]