# app/utils/helpers.py

import re


def validate_ip(ip):
    if not ip:
        return True
    return re.match(r'^(\d{1,3}\.){3}\d{1,3}$', ip) is not None


def format_duration(menit):
    if menit <= 0:
        return "Habis"
    
    jam = menit // 60
    sisa = menit % 60
    
    if jam == 0:
        return f"{sisa} Menit"
    elif sisa == 0:
        return f"{jam} Jam"
    else:
        return f"{jam} Jam {sisa}M"


def format_rupiah(nominal):
    return f"Rp{nominal:,}"