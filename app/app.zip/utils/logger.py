# app/utils/logger.py

import os
from datetime import datetime

LOG_DIR = "logs"
LOG_FILE = os.path.join(LOG_DIR, "warnet.log")

# Buat folder logs jika belum ada
os.makedirs(LOG_DIR, exist_ok=True)


def write_log(aksi, detail, user="kasir"):
    """Tulis log ke file"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{now}] [{user}] {aksi} - {detail}\n"
    
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(log_line)
    
    print(f"[LOG] {log_line.strip()}")


def read_logs(limit=500, filter_text=None):
    """Baca log dari file"""
    if not os.path.exists(LOG_FILE):
        return []
    
    logs = []
    with open(LOG_FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    # Balik urutan (yang terbaru di atas)
    for line in reversed(lines):
        if filter_text and filter_text.lower() not in line.lower():
            continue
        logs.append(line.strip())
        if len(logs) >= limit:
            break
    
    return logs


def clear_logs():
    """Hapus semua log"""
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w", encoding="utf-8") as f:
            f.write("")
        return True
    return False