# app/repositories/pc_repository.py

from app.models.base import db
from app.models.pc import PC


class PCRepository:

    @staticmethod
    def get_all(aktif_only=False):
        query = PC.query
        if aktif_only:
            query = query.filter_by(aktif=True)
        # Urutkan berdasarkan grup_id dan kode PC
        return query.order_by(PC.grup_id, PC.kode).all()

    @staticmethod
    def get_by_id(pc_id):
        return PC.query.get_or_404(pc_id)

    @staticmethod
    def get_by_kode(kode):
        return PC.query.filter_by(kode=kode, aktif=True).first()

    @staticmethod
    def get_by_ip(ip_address):
        return PC.query.filter_by(ip_address=ip_address, aktif=True).first()

    @staticmethod
    def get_by_ip_and_mac(ip_address, mac_address):
        return PC.query.filter_by(ip_address=ip_address, mac_address=mac_address, aktif=True).first()

    @staticmethod
    def find_by_kode(kode):
        """Cari PC by kode tanpa filter aktif (untuk cek duplikat)"""
        return PC.query.filter_by(kode=kode).first()

    @staticmethod
    def find_ip_exclude(ip, exclude_id):
        return PC.query.filter(PC.ip_address == ip, PC.id != exclude_id).first()

    @staticmethod
    def find_mac_exclude(mac, exclude_id):
        return PC.query.filter(PC.mac_address == mac, PC.id != exclude_id).first()

    @staticmethod
    def find_by_ip(ip):
        return PC.query.filter_by(ip_address=ip).first()

    @staticmethod
    def find_by_mac(mac):
        return PC.query.filter_by(mac_address=mac).first()

    @staticmethod
    def save(pc):
        db.session.add(pc)
        db.session.commit()

    @staticmethod
    def save_batch(pc_list):
        """Menyimpan banyak PC sekaligus (Bulk Save)"""
        from app.models.base import db
        db.session.add_all(pc_list)
        db.session.commit()

    @staticmethod
    def delete(pc):
        db.session.delete(pc)
        db.session.commit()

    @staticmethod
    def commit():
        db.session.commit()

   