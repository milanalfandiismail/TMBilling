# app/repositories/member_repository.py

from app.models.base import db
from app.models.member import Member


class MemberRepository:

    @staticmethod
    def get_all():
        """Mengambil semua member (aktif dan nonaktif)"""
        return Member.query.order_by(Member.username).all()

    @staticmethod
    def get_all_aktif():
        return Member.query.filter_by(aktif=True).all()

    @staticmethod
    def get_by_id(member_id):
        return Member.query.get_or_404(member_id)

    @staticmethod
    def get_by_username(username):
        return Member.query.filter_by(username=username, aktif=True).first()

    @staticmethod
    def find_by_username(username):
        """Cari member by username tanpa filter aktif (untuk cek duplikat)"""
        return Member.query.filter_by(username=username).first()

    @staticmethod
    def tambah_saldo_menit(member_id, tambahan_menit):
        """
        Refund otomatis: Menambahkan sisa menit kembali ke akun member
        akibat server mati / blackout.
        """
        # Sesuaikan dengan lokasi import model abang
        from app.models.member import Member 
        
        member = Member.query.get(member_id)
        if member:
            # Langsung tambahkan ke waktu_tersimpan (saldo)
            member.waktu_tersimpan += tambahan_menit
            
            # Catatan: Kita gak pakai db.session.commit() di sini
            # karena commit-nya udah dieksekusi massal di on_server_start()
            return True
            
        return False

    @staticmethod
    def save(member):
        db.session.add(member)
        db.session.commit()

    @staticmethod
    def delete(member):
        db.session.delete(member)
        db.session.commit()

    @staticmethod
    def commit():
        db.session.commit()