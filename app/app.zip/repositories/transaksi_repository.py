# app/repositories/transaksi_repository.py

from app.models.base import db
from app.models.transaksi import Transaksi
from sqlalchemy import func


class TransaksiRepository:

    @staticmethod
    def save(transaksi):
        db.session.add(transaksi)
        db.session.commit()

    @staticmethod
    def get_total_pendapatan_hari_ini(tanggal):
        return db.session.query(func.sum(Transaksi.jumlah)).filter(
            func.date(Transaksi.dibuat_pada) == tanggal,
            Transaksi.jenis.in_([
                "beli_paket_guest",
                "beli_paket_member",
                "tambah_waktu_sesi",
                "tambah_waktu_guest"
            ])
        ).scalar() or 0
    
    @staticmethod
    def get_last_paket_member(member_id):
        """Ambil transaksi paket member terakhir"""
        return Transaksi.query.filter_by(
            member_id=member_id,
            jenis="beli_paket_member"
        ).order_by(Transaksi.dibuat_pada.desc()).first()