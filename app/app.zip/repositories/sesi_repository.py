# app/repositories/sesi_repository.py

from app.models.base import db
from app.models.sesi import Sesi
from sqlalchemy import func 


class SesiRepository:

    @staticmethod
    def get_by_id(sesi_id):
        return Sesi.query.get_or_404(sesi_id)

    @staticmethod
    def get_aktif_by_pc(pc_id):
        return Sesi.query.filter_by(pc_id=pc_id, status="aktif").first()

    @staticmethod
    def get_aktif_by_id(sesi_id):
        return Sesi.query.filter_by(id=sesi_id, status="aktif").first()

    @staticmethod
    def get_aktif_by_member(member_id):
        return Sesi.query.filter_by(member_id=member_id, status="aktif").first()

    @staticmethod
    def get_aktif_by_paket(paket_id):
        return Sesi.query.filter_by(paket_id=paket_id, status="aktif").first()

    @staticmethod
    def get_all_aktif():
        return Sesi.query.filter_by(status="aktif").all()
    
    @staticmethod
    def get_all_suspects():
        """Ambil semua sesi yang kena flag suspect blackout"""
        from app.models.sesi import Sesi
        return Sesi.query.filter_by(is_blackout_suspect=True).all()
    
    @staticmethod
    def get_by_audit_status(is_resolved):
        # Query murni ada di sini
        return Sesi.query.filter_by(
            is_blackout_suspect=True, 
            is_blackout_resolved=is_resolved
        ).all()

    @staticmethod
    def get_aktif_tanpa_sync(sejak):
        """Ambil semua sesi aktif yang last_sync-nya sebelum waktu tertentu (atau null)"""
        from sqlalchemy import or_
        return Sesi.query.filter(
            Sesi.status == "aktif",
            or_(Sesi.last_sync == None, Sesi.last_sync < sejak)
        ).all()

    @staticmethod
    def save(sesi):
        """Menyimpan satu objek sesi"""
        db.session.add(sesi)
        db.session.commit()

    @staticmethod
    def save_with_transaksi(sesi, transaksi):
        """
        Menyimpan Sesi dan Transaksi secara atomik.
        Digunakan di fungsi buka_guest.
        """
        db.session.add(sesi)
        db.session.flush()  # Mengambil ID Sesi sebelum commit
        
        # Pastikan transaksi terhubung ke ID sesi yang baru dibuat
        transaksi.sesi_id = sesi.id 
        db.session.add(transaksi)
        
        db.session.commit()

    @staticmethod
    def update_and_add_transaksi(transaksi):
        """
        Menambahkan record transaksi baru dan meng-commit 
        perubahan status pada objek sesi terkait.
        """
        db.session.add(transaksi)
        db.session.commit()

    @staticmethod
    def update_last_sync(sesi):
        """Update last_sync sesi ke waktu sekarang"""
        from app.models.base import now_local
        sesi.last_sync = now_local()
        db.session.commit()

    @staticmethod
    def save_with_sesi_baru(sesi_lama, sesi_baru):
        """Tutup sesi lama dan buat sesi baru dalam satu commit (untuk guest lanjut di PC baru)"""
        from app.models.base import db
        db.session.add(sesi_baru)
        db.session.commit()

    @staticmethod
    def force_close_all_sesi(now):
        sesi_list = Sesi.query.filter_by(status="aktif").all()
        for sesi in sesi_list:
            sesi.status = "selesai"
            sesi.selesai_pada = now
        db.session.commit()
        return len(sesi_list)

    @staticmethod
    def count_by_date(target_date):
        """Menghitung total sesi berdasarkan tanggal mulai"""
        return Sesi.query.filter(
            func.date(Sesi.mulai_pada) == target_date
        ).count()
    
    @staticmethod
    def commit():
        """Melakukan commit untuk perubahan yang sudah ada"""
        db.session.commit()

    