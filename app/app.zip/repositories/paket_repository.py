# app/repositories/paket_repository.py

from app.models.base import db
from app.models.paket import Paket


class PaketRepository:

    @staticmethod
    def get_all(aktif_only=False, grup_id=None):
        query = Paket.query
        if aktif_only:
            query = query.filter_by(aktif=True)
        if grup_id:
            # Menggunakan grup_id sesuai model relasional
            query = query.filter_by(grup_id=grup_id) 
        return query.order_by(Paket.harga).all()
    
    @staticmethod
    def get_by_id(paket_id):
        return Paket.query.get_or_404(paket_id)

    @staticmethod
    def find_by_nama(nama):
        return Paket.query.filter_by(nama=nama).first()

    @staticmethod
    def find_by_nama_exclude(nama, exclude_id):
        return Paket.query.filter(Paket.nama == nama, Paket.id != exclude_id).first()

    @staticmethod
    def save(paket):
        db.session.add(paket)
        db.session.commit()

    @staticmethod
    def delete(paket):
        db.session.delete(paket)
        db.session.commit()

    @staticmethod
    def commit():
        db.session.commit()