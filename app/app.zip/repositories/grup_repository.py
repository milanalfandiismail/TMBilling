# app/repositories/grup_repository.py
from app.models.grup import Grup
from app.models.base import db

class GrupRepository:
    @staticmethod
    def get_all():
        return Grup.query.all()

    @staticmethod
    def get_by_id(id):
        return Grup.query.get(id)

    @staticmethod
    def save(grup):
        db.session.add(grup)
        db.session.commit()

    @staticmethod
    def delete(grup):
        db.session.delete(grup)
        db.session.commit()

    @staticmethod
    def commit():
        db.session.commit()

    @staticmethod
    def find_by_nama(nama):
        # Mencari objek grup berdasarkan nama (string)
        return Grup.query.filter_by(nama=nama.lower().strip()).first()