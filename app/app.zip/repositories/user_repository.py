# app/repositories/user_repository.py

from app.models.user import User


class UserRepository:

    @staticmethod
    def get_by_username(username):
        return User.query.filter_by(username=username, aktif=True).first()