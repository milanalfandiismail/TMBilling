# # app/models.py

# from app import db
# from datetime import datetime, timedelta

# def now_local():
#     return datetime.now()


# class Paket(db.Model):
#     __tablename__ = "paket"
    
#     id = db.Column(db.Integer, primary_key=True)
#     nama = db.Column(db.String(100), nullable=False, unique=True)  # ← TAMBAHKAN unique=True
#     durasi_menit = db.Column(db.Integer, nullable=False)
#     harga = db.Column(db.Integer, nullable=False)
#     kadaluarsa_hari = db.Column(db.Integer, default=30)
#     grup = db.Column(db.String(20), default="reguler")  # reguler, vip, vvip
#     aktif = db.Column(db.Boolean, default=True)
#     dibuat_pada = db.Column(db.DateTime, default=now_local)
    
#     def to_dict(self):
#         return {
#             "id": self.id,
#             "nama": self.nama,
#             "durasi_menit": self.durasi_menit,
#             "harga": self.harga,
#             "kadaluarsa_hari": self.kadaluarsa_hari,
#             "grup": self.grup,
#             "aktif": self.aktif,
#         }


# class Member(db.Model):
#     __tablename__ = "member"
    
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(50), unique=True, nullable=False)
#     password_hash = db.Column(db.String(256), nullable=False)
#     nama_lengkap = db.Column(db.String(100))
#     email = db.Column(db.String(120))
#     no_hp = db.Column(db.String(20))
#     grup = db.Column(db.String(20), default="reguler")
#     aktif = db.Column(db.Boolean, default=True)
#     dibuat_pada = db.Column(db.DateTime, default=now_local)
    
#     # Waktu tersimpan dari paket yang dibeli (dalam menit)
#     waktu_tersimpan = db.Column(db.Integer, default=0)
#     kadaluarsa_pada = db.Column(db.DateTime, nullable=True)
    
#     def set_password(self, password):
#         from werkzeug.security import generate_password_hash
#         self.password_hash = generate_password_hash(password)
    
#     def check_password(self, password):
#         from werkzeug.security import check_password_hash
#         return check_password_hash(self.password_hash, password)
    
#     def tambah_waktu(self, menit, kadaluarsa_hari):
#         """Tambah waktu tersimpan dari pembelian paket"""
#         self.waktu_tersimpan += menit
#         # Update kadaluarsa ke yang paling lama
#         baru_kadaluarsa = now_local() + timedelta(days=kadaluarsa_hari)
#         if not self.kadaluarsa_pada or baru_kadaluarsa > self.kadaluarsa_pada:
#             self.kadaluarsa_pada = baru_kadaluarsa
    
#     def kurangi_waktu(self, menit=1):
#         """Kurangi waktu tersimpan (dipanggil dari C++ client setiap menit)"""
#         if self.waktu_tersimpan >= menit:
#             self.waktu_tersimpan -= menit
#             return True, self.waktu_tersimpan
#         return False, 0
    
#     def cek_kadaluarsa(self):
#         """Cek dan bersihkan waktu yang sudah kadaluarsa"""
#         if self.kadaluarsa_pada and now_local() > self.kadaluarsa_pada:
#             self.waktu_tersimpan = 0
#             self.kadaluarsa_pada = None
#             return True
#         return False
    
#     def to_dict(self):
#         return {
#             "id": self.id,
#             "username": self.username,
#             "nama_lengkap": self.nama_lengkap,
#             "email": self.email,
#             "no_hp": self.no_hp,
#             "grup" : self.grup,
#             "waktu_tersimpan": self.waktu_tersimpan,
#             "kadaluarsa_pada": self.kadaluarsa_pada.strftime("%Y-%m-%d %H:%M:%S") if self.kadaluarsa_pada else None,
#             "aktif": self.aktif,
#             "dibuat_pada": self.dibuat_pada.strftime("%Y-%m-%d %H:%M:%S") if self.dibuat_pada else None,
#         }


# class PC(db.Model):
#     __tablename__ = "pc"
    
#     id = db.Column(db.Integer, primary_key=True)
#     kode = db.Column(db.String(20), unique=True, nullable=False)
#     nama = db.Column(db.String(50))
#     ip_address = db.Column(db.String(15), nullable=True)
#     grup = db.Column(db.String(20), default="reguler")
#     zona = db.Column(db.String(50), default="reguler")
#     aktif = db.Column(db.Boolean, default=True)
    
#     @property
#     def sesi_aktif(self):
#         return Sesi.query.filter_by(pc_id=self.id, status="aktif").first()
    
#     def to_dict(self):
#         s = self.sesi_aktif
#         sesi_detail = None
#         if s:
#             sesi_detail = s.to_dict()
#         return {
#             "id": self.id,
#             "kode": self.kode,
#             "nama": self.nama,
#             "ip_address": self.ip_address,
#             "grup": self.grup,
#             "zona": self.zona,
#             "aktif": self.aktif,
#             "status": "terpakai" if s else "kosong",
#             "sesi_id": s.id if s else None,
#             "sesi_detail": sesi_detail
#         }


# class Sesi(db.Model):
#     __tablename__ = "sesi"
    
#     id = db.Column(db.Integer, primary_key=True)
#     tipe = db.Column(db.String(10), nullable=False)  # guest / member
#     member_id = db.Column(db.Integer, db.ForeignKey("member.id"), nullable=True)
#     member = db.relationship("Member", backref="sesi_list")
#     pc_id = db.Column(db.Integer, db.ForeignKey("pc.id"), nullable=False)
#     pc = db.relationship("PC")
#     paket_id = db.Column(db.Integer, db.ForeignKey("paket.id"), nullable=True)
#     paket = db.relationship("Paket")
#     nama_guest = db.Column(db.String(100), nullable=True)
    
#     token_sesi = db.Column(db.String(64), unique=True, nullable=True)  # Untuk auth dari C++ client
    
#     mulai_pada = db.Column(db.DateTime, default=now_local)
#     selesai_pada = db.Column(db.DateTime, nullable=True)
    
#     durasi_beli_menit = db.Column(db.Integer, default=0)  # Untuk guest
#     total_bayar = db.Column(db.Integer, default=0)
#     status = db.Column(db.String(10), default="aktif")
    
#     def menit_terpakai(self):
#         if self.selesai_pada:
#             delta = self.selesai_pada - self.mulai_pada
#         else:
#             delta = now_local() - self.mulai_pada
#         return int(delta.total_seconds() / 60)
    
#     def sisa_menit(self):
#         if self.tipe == "guest":
#             sisa = max(0, self.durasi_beli_menit - self.menit_terpakai())
#         else:
#             sisa = self.member.waktu_tersimpan if self.member else 0
        
#         # AUTO-CLEANUP: jika sisa 0 dan status masih aktif, tutup sesi
#         if sisa <= 0 and self.status == "aktif":
#             self.status = "selesai"
#             self.selesai_pada = now_local()
#             db.session.commit()
        
#         return sisa
    
#     def to_dict(self):
#         member_nama = None
#         if self.member:
#             member_nama = self.member.nama_lengkap or self.member.username
#         elif self.nama_guest:
#             member_nama = self.nama_guest
        
#         return {
#             "id": self.id,
#             "tipe": self.tipe,
#             "member_id": self.member_id,
#             "member_nama": member_nama,
#             "nama_guest": self.nama_guest,
#             "pc_kode": self.pc.kode if self.pc else None,
#             "paket": self.paket.to_dict() if self.paket else None,
#             "mulai_pada": self.mulai_pada.strftime("%Y-%m-%d %H:%M:%S") if self.mulai_pada else None,
#             "selesai_pada": self.selesai_pada.strftime("%Y-%m-%d %H:%M:%S") if self.selesai_pada else None,
#             "sisa_menit": self.sisa_menit(),
#             "status": self.status,
#         }


# class Transaksi(db.Model):
#     __tablename__ = "transaksi"
    
#     id = db.Column(db.Integer, primary_key=True)
#     sesi_id = db.Column(db.Integer, db.ForeignKey("sesi.id"), nullable=True)
#     member_id = db.Column(db.Integer, db.ForeignKey("member.id"), nullable=True)
#     paket_id = db.Column(db.Integer, db.ForeignKey("paket.id"), nullable=True)

#     jenis = db.Column(db.String(30), nullable=False)  # beli_paket_guest, beli_paket_member, tambah_waktu
#     jumlah = db.Column(db.Integer, default=0)  # Harga
#     menit = db.Column(db.Integer, default=0)  # Durasi
#     keterangan = db.Column(db.String(200))
#     dibuat_pada = db.Column(db.DateTime, default=now_local)
    
#     def to_dict(self):
#         return {
#             "id": self.id,
#             "jenis": self.jenis,
#             "jumlah": self.jumlah,
#             "menit": self.menit,
#             "keterangan": self.keterangan,
#             "dibuat_pada": self.dibuat_pada.strftime("%Y-%m-%d %H:%M:%S") if self.dibuat_pada else None,
#         }

# class User(db.Model):
#     __tablename__ = "user"
    
#     id = db.Column(db.Integer, primary_key=True)
#     username = db.Column(db.String(50), unique=True, nullable=False)
#     password_hash = db.Column(db.String(256), nullable=False)
#     nama_lengkap = db.Column(db.String(100))
#     role = db.Column(db.String(20), default="kasir")  # admin, kasir
#     aktif = db.Column(db.Boolean, default=True)
#     dibuat_pada = db.Column(db.DateTime, default=now_local)
    
#     def set_password(self, password):
#         from werkzeug.security import generate_password_hash
#         self.password_hash = generate_password_hash(password)
    
#     def check_password(self, password):
#         from werkzeug.security import check_password_hash
#         return check_password_hash(self.password_hash, password)
    
#     def to_dict(self):
#         return {
#             "id": self.id,
#             "username": self.username,
#             "nama_lengkap": self.nama_lengkap,
#             "role": self.role,
#             "aktif": self.aktif,
#         }