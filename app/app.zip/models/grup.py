# app/models/grup.py
from app.models.base import db, now_local

class Grup(db.Model):
    __tablename__ = 'grup'
    id = db.Column(db.Integer, primary_key=True)
    nama = db.Column(db.String(50), unique=True, nullable=False) # reguler, vip, dll
    keterangan = db.Column(db.String(255), nullable=True)
    dibuat_pada = db.Column(db.DateTime, default=now_local)

    def __init__(self, nama, keterangan=None):
        self.nama = nama.lower().strip()
        self.keterangan = keterangan