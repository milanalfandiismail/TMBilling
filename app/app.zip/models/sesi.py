# app/models/sesi.py

from app.models.base import db, now_local

class Sesi(db.Model):
    __tablename__ = "sesi"
    
    id = db.Column(db.Integer, primary_key=True)
    tipe = db.Column(db.String(10), nullable=False)
    
    # Relasi ke Member
    member_id = db.Column(db.Integer, db.ForeignKey("member.id"), nullable=True)
    member = db.relationship("Member", backref="sesi_list")
    
    # Relasi ke PC
    pc_id = db.Column(db.Integer, db.ForeignKey("pc.id", ondelete="SET NULL"), nullable=True)
    pc = db.relationship('PC', back_populates='sesi_list')    
    
    # Relasi ke Paket
    paket_id = db.Column(db.Integer, db.ForeignKey("paket.id"), nullable=True)
    paket = db.relationship("Paket")
    
    nama_guest = db.Column(db.String(100), nullable=True)
    token_sesi = db.Column(db.String(64), unique=True, nullable=True)
    
    mulai_pada = db.Column(db.DateTime, default=now_local)
    selesai_pada = db.Column(db.DateTime, nullable=True)
    durasi_beli_menit = db.Column(db.Integer, default=0)
    total_bayar = db.Column(db.Integer, default=0)
    status = db.Column(db.String(10), default="aktif")
    
    # Logika sinkronisasi waktu
    waktu_mulai_sesi = db.Column(db.DateTime, nullable=True)
    waktu_tersimpan_awal = db.Column(db.Integer, default=0)
    last_sync = db.Column(db.DateTime, nullable=True)
    menit_pause_total = db.Column(db.Integer, default=0)

    # Kolom baru untuk "Screenshot Audit Mati Lampu"
    sisa_menit_saat_mati = db.Column(db.Integer, default=0)
    is_blackout_suspect = db.Column(db.Boolean, default=False) # Apakah kena blackout?
    is_blackout_resolved = db.Column(db.Boolean, default=False) # Apakah sudah di-klik 'Selesai'?
    waktu_resolved = db.Column(db.DateTime, nullable=True) # Catatan waktu pas kasir klik 'Selesai'

    def hitung_sisa_pada(self, waktu_acuan):
        """
        Menghitung sisa menit pada titik waktu tertentu (misal: pas last_sync).
        """
        if not waktu_acuan:
            return 0
            
        # 1. Tentukan jam mulai
        waktu_awal = self.waktu_mulai_sesi if self.tipe == "member" else self.mulai_pada
        
        # 2. Tentukan "Modal Waktu" awal (Ganti total_menit yang error tadi)
        # Jika member pakai waktu_tersimpan_awal, jika guest pakai durasi_beli_menit
        total_awal = self.waktu_tersimpan_awal if self.tipe == "member" else self.durasi_beli_menit
        
        # 3. Hitung menit yang sudah berjalan sampai waktu_acuan
        delta = waktu_acuan - waktu_awal
        menit_terpakai_raw = int(delta.total_seconds() / 60)
        
        # 4. Sisa = (Modal + Pause) - Terpakai
        pause = self.menit_pause_total or 0
        sisa = (total_awal + pause) - menit_terpakai_raw
        
        return max(0, sisa)


    def menit_terpakai(self):
        """Menghitung total menit yang sudah berjalan, dikurangi total pause blackout"""
        pause = self.menit_pause_total or 0
        if self.tipe == "guest":
            if self.selesai_pada:
                delta = self.selesai_pada - self.mulai_pada
            else:
                delta = now_local() - self.mulai_pada
            raw = max(0, int(delta.total_seconds() / 60))
            return max(0, raw - pause)
        else:
            if self.waktu_mulai_sesi:
                delta = now_local() - self.waktu_mulai_sesi
                raw = max(0, int(delta.total_seconds() / 60))
                return max(0, raw - pause)
            return 0
    
    def sisa_menit(self):
        """Menghitung sisa menit secara real-time, memperhitungkan blackout pause"""
        pause = self.menit_pause_total or 0
        if self.tipe == "guest":
            return max(0, self.durasi_beli_menit - self.menit_terpakai())
        else:
            if self.waktu_mulai_sesi and self.waktu_tersimpan_awal > 0:
                delta = now_local() - self.waktu_mulai_sesi
                menit_terpakai = max(0, int(delta.total_seconds() / 60) - pause)
                return max(0, self.waktu_tersimpan_awal - menit_terpakai)
            return self.member.waktu_tersimpan if self.member else 0
    
    def to_dict(self):
        """Konversi data sesi ke JSON untuk API"""
        member_nama = None
        if self.member:
            member_nama = self.member.nama_lengkap or self.member.username
        elif self.nama_guest:
            member_nama = self.nama_guest
        
        return {
            "id": self.id,
            "tipe": self.tipe,
            "member_id": self.member_id,
            "member_nama": member_nama,
            "nama_guest": self.nama_guest,
            "pc_kode": self.pc.kode if self.pc else None,
            # 🟢 PENYESUAIAN GRUP: Ambil nama dari relasi PC ke Grup
            "grup": self.pc.grup.nama if self.pc and self.pc.grup else "reguler",
            "paket": self.paket.to_dict() if self.paket else None,
            "mulai_pada": self.mulai_pada.strftime("%Y-%m-%d %H:%M:%S") if self.mulai_pada else None,
            "selesai_pada": self.selesai_pada.strftime("%Y-%m-%d %H:%M:%S") if self.selesai_pada else None,
            "sisa_menit": self.sisa_menit(),
            "status": self.status,
            "waktu_mulai_sesi": self.waktu_mulai_sesi.strftime("%Y-%m-%d %H:%M:%S") if self.waktu_mulai_sesi else None,
            "waktu_tersimpan_awal": self.waktu_tersimpan_awal,
            "menit_pause_total": self.menit_pause_total,
            "last_sync": self.last_sync.strftime("%Y-%m-%d %H:%M:%S") if self.last_sync else None,
        }
    
    def to_dict_audit(self):
        """Digunakan untuk halaman Audit Blackout"""
        return {
            "id": self.id,
            "pc_kode": self.pc.kode if self.pc else "??",
            "username": self.member.username if self.member else self.nama_guest or "Guest",
            "tipe": self.tipe,
            "jam_mati": self.last_sync.strftime("%H:%M:%S") if self.last_sync else self.mulai_pada.strftime("%H:%M:%S"),
            "sisa_waktu_mati": self.sisa_menit_saat_mati or 0,
            # ← FIELD INI YANG KURANG SEBELUMNYA
            "is_blackout_resolved": self.is_blackout_resolved
        }