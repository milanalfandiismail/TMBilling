# app/models/member.py

from app.models.base import db, now_local
from datetime import timedelta

class Member(db.Model):
    __tablename__ = "member"
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    nama_lengkap = db.Column(db.String(100))
    email = db.Column(db.String(120))
    no_hp = db.Column(db.String(20))
    
    # 🔗 Relasi Baru ke Tabel Grup
    grup_id = db.Column(db.Integer, db.ForeignKey("grup.id"), nullable=False)
    grup = db.relationship("Grup", backref="member_list")
    
    aktif = db.Column(db.Boolean, default=True)
    dibuat_pada = db.Column(db.DateTime, default=now_local)
    
    waktu_tersimpan = db.Column(db.Integer, default=0)
    kadaluarsa_pada = db.Column(db.DateTime, nullable=True)
    
    def set_password(self, password):
        from werkzeug.security import generate_password_hash
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        from werkzeug.security import check_password_hash
        return check_password_hash(self.password_hash, password)
    
    def tambah_waktu(self, menit, kadaluarsa_hari):
        self.waktu_tersimpan += menit
        baru_kadaluarsa = now_local() + timedelta(days=kadaluarsa_hari)
        if not self.kadaluarsa_pada or baru_kadaluarsa > self.kadaluarsa_pada:
            self.kadaluarsa_pada = baru_kadaluarsa
    
    def kurangi_waktu(self, menit=1):
        if self.waktu_tersimpan >= menit:
            self.waktu_tersimpan -= menit
            return True, self.waktu_tersimpan
        return False, 0
    
    def cek_kadaluarsa(self):
        if self.kadaluarsa_pada and now_local() > self.kadaluarsa_pada:
            self.waktu_tersimpan = 0
            self.kadaluarsa_pada = None
            return True
        return False
    
    def to_dict(self):
        """Memastikan frontend tetap menerima teks nama grup"""
        return {
            "id": self.id,
            "username": self.username,
            "nama_lengkap": self.nama_lengkap,
            "email": self.email,
            "no_hp": self.no_hp,
            # Ambil nama dari relasi grup, default 'reguler' jika kosong
            "grup": self.grup.nama if self.grup else "reguler", 
            "waktu_tersimpan": self.waktu_tersimpan,
            "kadaluarsa_pada": self.kadaluarsa_pada.strftime("%Y-%m-%d %H:%M:%S") if self.kadaluarsa_pada else None,
            "aktif": self.aktif,
            "dibuat_pada": self.dibuat_pada.strftime("%Y-%m-%d %H:%M:%S") if self.dibuat_pada else None,
        }