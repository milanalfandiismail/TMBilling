# app/models/transaksi.py

from app.models.base import db, now_local


class Transaksi(db.Model):
    __tablename__ = "transaksi"
    
    id = db.Column(db.Integer, primary_key=True)
    sesi_id = db.Column(db.Integer, db.ForeignKey("sesi.id"), nullable=True)
    member_id = db.Column(db.Integer, db.ForeignKey("member.id", ondelete="SET NULL"), nullable=True)
    paket_id = db.Column(db.Integer, db.ForeignKey("paket.id"), nullable=True)
    
    jenis = db.Column(db.String(30), nullable=False)
    jumlah = db.Column(db.Integer, default=0)
    menit = db.Column(db.Integer, default=0)
    keterangan = db.Column(db.String(200))
    dibuat_pada = db.Column(db.DateTime, default=now_local)
    
    # Relationships
    sesi = db.relationship("Sesi", backref="transaksi_list")
    member = db.relationship("Member", backref="transaksi_list")
    paket = db.relationship("Paket", backref="transaksi_list")
    
    def to_dict(self):
        return {
            "id": self.id,
            "sesi_id": self.sesi_id,
            "member_id": self.member_id,
            "member_nama": self.member.nama_lengkap or self.member.username if self.member else None,
            "paket_id": self.paket_id,
            "paket_nama": self.paket.nama if self.paket else None,
            "jenis": self.jenis,
            "jenis_display": self._get_jenis_display(),
            "jumlah": self.jumlah,
            "jumlah_display": f"Rp{self.jumlah:,}" if self.jumlah > 0 else "-",
            "menit": self.menit,
            "menit_display": f"{self.menit} menit" if self.menit > 0 else "-",
            "keterangan": self.keterangan,
            "dibuat_pada": self.dibuat_pada.strftime("%Y-%m-%d %H:%M:%S") if self.dibuat_pada else None,
        }
    
    def _get_jenis_display(self):
        jenis_map = {
            "beli_paket_guest": "🎮 Guest Beli Paket",
            "beli_paket_member": "👤 Member Beli Paket",
            "tambah_waktu_sesi": "⏰ Member Tambah Waktu",
            "tambah_waktu_guest": "⏱️ Guest Tambah Waktu",
            "tutup_sesi": "🔒 Tutup Sesi",
            "pindah_pc": "🔄 Pindah PC" 
        }
        return jenis_map.get(self.jenis, self.jenis)