# app/models/base.py

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

def now_local():
    return datetime.now()