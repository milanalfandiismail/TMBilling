# app/models/paket.py

from app.models.base import db, now_local

class Paket(db.Model):
    __tablename__ = "paket"
    
    id = db.Column(db.Integer, primary_key=True)
    nama = db.Column(db.String(100), nullable=False, unique=True)
    durasi_menit = db.Column(db.Integer, nullable=False)
    harga = db.Column(db.Integer, nullable=False)
    kadaluarsa_hari = db.Column(db.Integer, default=30)
    
    # 🔗 Relasi Baru ke Tabel Grup
    grup_id = db.Column(db.Integer, db.ForeignKey("grup.id"), nullable=False)
    grup = db.relationship("Grup", backref="paket_list")
    
    aktif = db.Column(db.Boolean, default=True)
    dibuat_pada = db.Column(db.DateTime, default=now_local)
    
    def to_dict(self):
        """Konversi data Paket ke format JSON untuk frontend"""
        return {
            "id": self.id,
            "nama": self.nama,
            "durasi_menit": self.durasi_menit,
            "harga": self.harga,
            "kadaluarsa_hari": self.kadaluarsa_hari,
            # Mengambil nama grup dari relasi, bukan objek grup utuh
            "grup": self.grup.nama if self.grup else "reguler", 
            "aktif": self.aktif,
        }