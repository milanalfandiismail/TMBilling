# app/models/pc.py

from app.models.base import db

class PC(db.Model):
    __tablename__ = "pc"
    
    id = db.Column(db.Integer, primary_key=True)
    kode = db.Column(db.String(20), unique=True, nullable=False)
    nama = db.Column(db.String(50))
    ip_address = db.Column(db.String(15), nullable=True)
    mac_address = db.Column(db.String(17), nullable=True)
    
    # 🔗 Relasi Baru ke Tabel Grup
    grup_id = db.Column(db.Integer, db.ForeignKey("grup.id"), nullable=False)
    grup = db.relationship("Grup", backref="pc_list")
    
    # Relasi ke Sesi
    sesi_list = db.relationship('Sesi', back_populates='pc', lazy='dynamic')    
    
    zona = db.Column(db.String(50), default="reguler")
    last_activity = db.Column(db.DateTime, nullable=True)
    aktif = db.Column(db.Boolean, default=True)

    @property
    def zona_nama(self):
        """Zona selalu mengikuti nama grup secara dinamis"""
        return self.grup.nama if self.grup else "reguler"
    
    @property
    def sesi_aktif(self):
        """Mengecek apakah ada sesi aktif di PC ini via relasi"""
        return self.sesi_list.filter_by(status="aktif").first()
    
    def to_dict(self):
        """Konversi data PC ke format JSON untuk frontend"""
        s = self.sesi_aktif
        return {
            "id": self.id,
            "kode": self.kode,
            "nama": self.nama,
            "ip_address": self.ip_address,
            "mac_address" : self.mac_address,
            # Mengambil nama grup dari relasi
            "grup": self.grup.nama if self.grup else "reguler", 
            "zona": self.zona_nama,
            "aktif": self.aktif,
            "status": "terpakai" if s else "kosong",
            "sesi_id": s.id if s else None,
        }