const Modal = {
    activeModal: null,
    escHandler: null,

    open(id) {
        const el = document.getElementById(id);
        if (el) {
            el.classList.remove('hidden');
            el.classList.add('flex');
            document.body.style.overflow = 'hidden';
        }
    },

    close(id) {
        const el = document.getElementById(id);
        if (el) {
            el.classList.add('hidden');
            el.classList.remove('flex');
            document.body.style.overflow = '';
        }
    },

    show(html, onClose) {
        if (this.activeModal) this.closeModal();
        const modalDiv = document.createElement('div');
        modalDiv.className = 'fixed inset-0 bg-black/80 flex items-center justify-center z-50';
        modalDiv.innerHTML = `<div class="bg-[#141414] border border-[#2a2a2a] rounded-lg p-5 max-w-md w-full max-h-[85vh] overflow-auto">${html}</div>`;
        document.body.appendChild(modalDiv);
        document.body.style.overflow = 'hidden';
        this.activeModal = modalDiv;
        modalDiv.addEventListener('click', (e) => { if (e.target === modalDiv) this.closeModal(onClose); });
        this.escHandler = (e) => { if (e.key === 'Escape') this.closeModal(onClose); };
        document.addEventListener('keydown', this.escHandler);
    },

    closeModal(onClose) {
        if (this.activeModal) {
            this.activeModal.remove();
            this.activeModal = null;
            document.body.style.overflow = '';
            if (this.escHandler) document.removeEventListener('keydown', this.escHandler);
            if (onClose && typeof onClose === 'function') onClose();
        }
    },

    confirm(message, onConfirm, onCancel) {
        // Buat konten modal konfirmasi
        const content = `
            <div>
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-sm uppercase tracking-wide">Konfirmasi</h3>
                    <button class="text-gray-400 hover:text-white text-xl" id="modal-close-btn">&times;</button>
                </div>
                <div class="mb-6 text-gray-300">${Utils.escapeHtml(message)}</div>
                <div class="flex gap-2 justify-end">
                    <button class="btn btn-secondary" id="modal-cancel-btn">Batal</button>
                    <button class="btn btn-primary" id="modal-confirm-btn">Ya, Lanjutkan</button>
                </div>
            </div>
        `;
        this.show(content, () => {
            // onClose saat modal ditutup (misal klik backdrop atau ESC)
            if (onCancel && typeof onCancel === 'function') onCancel();
        });
        // Setelah modal ditampilkan, pasang event listener untuk tombol
        setTimeout(() => {
            const confirmBtn = document.getElementById('modal-confirm-btn');
            const cancelBtn = document.getElementById('modal-cancel-btn');
            const closeBtn = document.getElementById('modal-close-btn');
            if (confirmBtn) confirmBtn.onclick = () => {
                this.closeModal();
                if (onConfirm && typeof onConfirm === 'function') onConfirm();
            };
            if (cancelBtn) cancelBtn.onclick = () => {
                this.closeModal();
                if (onCancel && typeof onCancel === 'function') onCancel();
            };
            if (closeBtn) closeBtn.onclick = () => {
                this.closeModal();
                if (onCancel && typeof onCancel === 'function') onCancel();
            };
        }, 10);
    }
};