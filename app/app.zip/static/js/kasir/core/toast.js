const Toast = {
    container: null,
    init() {
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.className = 'fixed bottom-4 right-4 z-50 flex flex-col gap-2';
            document.body.appendChild(this.container);
        }
    },
    show(msg, type = 'success') {
        this.init();
        const toast = document.createElement('div');
        toast.className = `px-4 py-2 rounded shadow-lg text-sm transition-all duration-300 transform translate-x-full ${type === 'error' ? 'bg-red-600' : 'bg-green-600'} text-white`;
        toast.textContent = msg;
        this.container.appendChild(toast);
        setTimeout(() => toast.classList.remove('translate-x-full'), 10);
        setTimeout(() => {
            toast.classList.add('translate-x-full');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },
    success(msg) { this.show(msg, 'success'); },
    error(msg) { this.show(msg, 'error'); }
};