// static/js/kasir/core/api.js

const API = {
    base: '',
    async request(url, options = {}) {
        try {
            const res = await fetch(this.base + url, {
                ...options,
                headers: { 'Content-Type': 'application/json', ...options.headers },
                credentials: 'include'
            });
            const txt = await res.text();
            let data;
            try { data = JSON.parse(txt); } catch (e) { data = { error: txt }; }
            if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
            return data;
        } catch (err) {
            console.error(`API Error [${url}]:`, err);
            throw err;
        }
    },

    // 🔗 AUTH KASIR
    auth: {
        login: (u, p) => API.request('/api/kasir/login', { method: 'POST', body: JSON.stringify({ username: u, password: p }) }),
        logout: () => API.request('/api/kasir/logout', { method: 'POST' }),
        check: () => API.request('/api/kasir/check')
    },

    // 🔗 DASHBOARD
    dashboard: {
        // Mengambil data PC yang sudah dikelompokkan berdasarkan grup
        pcList: () => API.request('/kasir/api/pc')
    },

    // 🟢 KELOLA GRUP (Baru ditambahkan agar FE dinamis)
    grup: {
        list: () => API.request('/api/grup/'),
        create: (data) => API.request('/api/grup/', { method: 'POST', body: JSON.stringify(data) }),
        delete: (id) => API.request(`/api/grup/${id}`, { method: 'DELETE' })
    },

    // 🔗 KELOLA MEMBER
    member: {
        list: () => API.request('/api/member'),
        get: id => API.request(`/api/member/${id}`),
        create: data => API.request('/api/member', { method: 'POST', body: JSON.stringify(data) }),
        update: (id, data) => API.request(`/api/member/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
        delete: id => API.request(`/api/member/${id}`, { method: 'DELETE' }),
        tambahWaktu: (memberId, paketId) => API.request('/api/tambah-waktu', { method: 'POST', body: JSON.stringify({ member_id: memberId, paket_id: paketId }) })
    },

    // 🔗 KELOLA PAKET
    paket: {
        list: (params = {}) => {
            const q = new URLSearchParams();
            if (params.aktif_only) q.append('aktif', 'true');
            if (params.grup) q.append('grup', params.grup);

            // 🟢 PASTIKAN JADI BEGINI (Tanpa slash di akhir kata paket)
            const url = '/api/paket' + (q.toString() ? `?${q}` : '');
            return API.request(url);
        },
        create: data => API.request('/api/paket/', { method: 'POST', body: JSON.stringify(data) }),
        update: (id, data) => API.request(`/api/paket/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
        delete: id => API.request(`/api/paket/${id}`, { method: 'DELETE' })
    },

    // 🔗 KELOLA PC
    pc: {
        list: () => API.request('/api/pc'),
        create: data => API.request('/api/pc', { method: 'POST', body: JSON.stringify(data) }),
        update: (id, data) => API.request(`/api/pc/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
        delete: id => API.request(`/api/pc/${id}`, { method: 'DELETE' }),
        batch: data => API.request('/api/pc/batch', { method: 'POST', body: JSON.stringify(data) })
    },

    // 🔗 LOGIKA SESI (GUEST & MEMBER)
    sesi: {
        bukaGuest: (pcKode, paketId, namaGuest) => API.request('/api/sesi/buka-guest', { method: 'POST', body: JSON.stringify({ pc_kode: pcKode, paket_id: paketId, nama_guest: namaGuest }) }),
        bukaMember: (pcKode, username) => API.request('/api/sesi/buka-member', { method: 'POST', body: JSON.stringify({ pc_kode: pcKode, username }) }),
        tambahWaktu: (sesiId, paketId) => API.request(`/api/sesi/tambah-waktu-sesi/${sesiId}`, { method: 'POST', body: JSON.stringify({ paket_id: paketId }) }),
        tutup: sesiId => API.request(`/api/sesi/tutup/${sesiId}`, { method: 'POST' }),
        pindahPC: (sesiId, pcKodeBaru) => API.request(`/api/sesi/pindah-pc/${sesiId}`, { method: 'POST', body: JSON.stringify({ pc_kode_baru: pcKodeBaru }) }),
        detail: sesiId => API.request(`/api/sesi/sesi/${sesiId}`)
    },

    // 🔗 LAPORAN & LOG
    report: {
        harian: () => API.request('/api/report/laporan-harian'),
        logs: (filter = '', limit = 500) => {
            const q = new URLSearchParams();
            if (filter) q.append('filter', filter);
            if (limit) q.append('limit', limit);
            return API.request(`/api/report/log?${q}`);
        },
        clearLogs: () => API.request('/api/report/log/clear', { method: 'POST' }),
        exportLogsUrl: (filter = '') => {
            let url = '/api/report/log/export';
            if (filter) url += `?filter=${encodeURIComponent(filter)}`;
            return url;
        }
    },

    // ⚡ BLACKOUT (MANUAL)
    blackout: {
        deteksi: (threshold) => API.request('/api/blackout/deteksi', { method: 'POST', body: JSON.stringify({ threshold_menit: threshold }) }),
        list: (date) => API.request(`/api/blackout/list${date ? '?date=' + date : ''}`),
        dates: () => API.request('/api/blackout/dates'),
        resolveMember: (sesiId) => API.request(`/api/blackout/resolve/member/${sesiId}`, { method: 'POST' }),
        resolveGuestLanjut: (sesiId, pcBaru) => API.request(`/api/blackout/resolve/guest/lanjut/${sesiId}`, { method: 'POST', body: JSON.stringify({ pc_baru_id: pcBaru }) }),
        resolveGuestTutup: (sesiId) => API.request(`/api/blackout/resolve/guest/tutup/${sesiId}`, { method: 'POST' }),
        resolveGuestSama: (sesiId) => API.request(`/api/blackout/resolve/guest/sama/${sesiId}`, { method: 'POST' }),
        clearResolved: (date) => API.request('/api/blackout/clear', { method: 'POST', body: JSON.stringify({ date }) }),
        forceAllAndDetect: () => API.request('/api/blackout/force-all-and-detect', { method: 'POST' }),
    },

};

// Pastikan object API bisa diakses secara global oleh file JS lainnya
window.API = API;