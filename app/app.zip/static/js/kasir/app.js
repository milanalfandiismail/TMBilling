const App = {
    currentTab: 'dash',
    async init() {
        const loggedIn = await this.checkAuth();
        if (!loggedIn) return;
        this.setupNavigation();
        await this.loadTab('dash');
        await Grup.load();
        // Cek apakah ada recovery blackout saat server start
        this.checkBlackoutBanner();
        setInterval(() => {
            if (this.currentTab === 'dash') Dashboard.load();
        }, 5000);
    },
    async checkAuth() {
        try {
            const result = await API.auth.check();
            if (!result.logged_in) {
                window.location.href = '/kasir/login';
                return false;
            }
            document.getElementById('user-info').innerText = result.username || 'Kasir';
            return true;
        } catch (err) {
            window.location.href = '/kasir/login';
            return false;
        }
    },
    setupNavigation() {
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                if (tab) this.switchTab(tab);
            });
        });
    },
    switchTab(tab) {
        document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
        const activeBtn = document.querySelector(`.nav-btn[data-tab="${tab}"]`);
        if (activeBtn) activeBtn.classList.add('active');
        document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
        const target = document.getElementById(`tab-${tab}`);
        if (target) target.classList.remove('hidden');
        this.currentTab = tab;
        this.loadTab(tab);
    },
    async loadTab(tab) {
        switch (tab) {
            case 'dash': await Dashboard.load(); break;
            case 'pc': await PC.load(); break;
            case 'paket': await Paket.load(); break;
            case 'member': await Member.load(); break;
            case 'laporan': await Laporan.load(); break;
            case 'log': await Log.load(); break;
            case 'grup': await Grup.load(); break;
            case 'blackout': await Blackout.load(); break;
        }
    },
    async checkBlackoutBanner() {
        try {
            const data = await API.blackout.logs();
            // Cek apakah log terbaru adalah SERVER_RESTART (dalam 5 menit terakhir)
            const logs = data.logs || [];
            const terbaru = logs[0] || '';
            if (terbaru.includes('SERVER_RESTART')) {
                // Parse angkanya dari log
                const mMatch = terbaru.match(/Member fix:(\d+)/);
                const gMatch = terbaru.match(/Guest freeze:(\d+)/);
                const member_fixed  = mMatch ? parseInt(mMatch[1]) : 0;
                const guest_flagged = gMatch ? parseInt(gMatch[1]) : 0;
                if (member_fixed > 0 || guest_flagged > 0) {
                    Blackout.showBanner({ member_fixed, guest_flagged });
                    // Highlight nav blackout
                    const nav = document.getElementById('nav-blackout');
                    if (nav) nav.classList.add('text-yellow-400');
                }
            }
        } catch (err) { /* silent */ }
    },

    async logout() {
        Modal.confirm('Yakin logout?', async () => {
            try {
                await API.auth.logout();
                window.location.href = '/kasir/login';
            } catch (err) {
                Toast.error('Logout gagal');
            }
        });
    }
};

document.addEventListener('DOMContentLoaded', () => App.init());

// Global exports for inline handlers
window.App = App;
window.PC = PC;
window.Paket = Paket;
window.Member = Member;
window.Laporan = Laporan;
window.Log = Log;
window.BukaModal = BukaModal;
window.Blackout = Blackout;
window.TambahModal = TambahModal;
window.Modal = Modal;
window.Toast = Toast;