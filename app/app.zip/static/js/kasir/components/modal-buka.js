// static/js/kasir/components/modal-buka.js
const BukaModal = {
    pcKode: null,
    pcGrup: null, // 🟢 Tambahkan properti untuk simpan grup

    // 🟢 Tangkap parameter ke-2 (pcGrup)
    open(pcKode, pcGrup) {
        this.pcKode = pcKode;
        this.pcGrup = pcGrup; 
        
        const inputKode = document.getElementById('buka-pc-kode');
        if(inputKode) inputKode.value = pcKode;
        
        this.loadPaket();
        Modal.open('mod-buka');
    },

    async loadPaket() {
        try {
            const data = await API.paket.list({ aktif_only: true });
            let paketList = data.paket || data.paket_list || [];

            // 🟢 FILTER FRONTEND: Cuma tampilkan paket yang grupnya sama dengan PC
            if (this.pcGrup) {
                paketList = paketList.filter(p => {
                    const namaGrupPaket = typeof p.grup === 'object' ? p.grup.nama : p.grup;
                    return (namaGrupPaket || 'reguler').toLowerCase() === this.pcGrup.toLowerCase();
                });
            }

            const select = document.getElementById('buka-paket');
            select.innerHTML = '<option value="">-- Pilih Paket --</option>';

            // Kasih tahu kasir kalau misal paket di zona itu lagi kosong/belum dibuat
            if (paketList.length === 0) {
                select.innerHTML = `<option value="">-- Tidak ada paket untuk ${this.pcGrup.toUpperCase()} --</option>`;
                return;
            }

            paketList.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id;
                opt.textContent = `${p.nama} (${p.durasi_menit}m) - ${Utils.formatRupiah(p.harga)}`;
                select.appendChild(opt);
            });
        } catch (err) {
            console.error('BukaModal loadPaket error:', err);
            Toast.error('Gagal memuat paket');
        }
    },

    async submit() {
        const paketId = document.getElementById('buka-paket').value;
        const inputGuest = document.getElementById('buka-guest');
        const namaGuest = (inputGuest ? inputGuest.value.trim() : '') || 'Guest';
        
        if (!paketId) return Toast.error('Pilih paket terlebih dahulu');
        
        try {
            await API.sesi.bukaGuest(this.pcKode, paketId, namaGuest);
            Toast.success(`Sesi guest dibuka di PC ${this.pcKode}`);
            Modal.close('mod-buka');
            
            if (typeof Dashboard !== 'undefined') Dashboard.load();
        } catch (err) {
            Toast.error(err.message);
        }
    }
};