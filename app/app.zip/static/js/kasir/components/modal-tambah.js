// static/js/kasir/components/modal-tambah.js
const TambahModal = {
    sesiId: null,

    // 🟢 TANGKAP PARAMETER pcGrup dari dashboard.js
    async open(sesiId, pcGrup) {
        this.sesiId = sesiId;
        
        try {
            // 1. Ambil SEMUA paket yang aktif dari API
            const data = await API.paket.list({ aktif_only: true });
            let paketList = data.paket || data.paket_list || [];
            
            // 🟢 2. FILTER DI FRONTEND: 
            // Cuma simpan paket yang nama grupnya sama dengan grup PC
            if (pcGrup) {
                paketList = paketList.filter(p => {
                    // Jaga-jaga kalau backend ngirim objek grup atau cuma string
                    const namaGrupPaket = typeof p.grup === 'object' ? p.grup.nama : p.grup;
                    // Cocokkan tanpa mempedulikan huruf besar/kecil (reguler == REGULER)
                    return (namaGrupPaket || 'reguler').toLowerCase() === pcGrup.toLowerCase();
                });
            }

            if (!paketList.length) {
                return Toast.error(`Belum ada paket aktif untuk zona ${pcGrup ? pcGrup.toUpperCase() : 'ini'}`);
            }

            // 3. Render HTML Option Dropdown
            const options = paketList.map(p => `
                <option value="${p.id}">${p.nama} (${p.durasi_menit}m) - ${Utils.formatRupiah(p.harga)}</option>
            `).join('');

            // 4. Tampilkan Modalnya
            const html = `
                <div class="p-1">
                    <h3 class="text-sm font-bold uppercase mb-4 text-green-500 border-b border-gray-800 pb-2">
                        Tambah Waktu <span class="text-gray-400">(${pcGrup ? pcGrup.toUpperCase() : ''})</span>
                    </h3>
                    <div class="mb-5">
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">Pilih Paket</label>
                        <select id="tambah-paket" class="form-input bg-gray-900 border-gray-700 w-full">
                            <option value="">-- Pilih Paket --</option>
                            ${options}
                        </select>
                    </div>
                    <div class="flex gap-2 justify-end mt-6">
                        <button class="px-4 py-2 text-sm text-gray-400 hover:text-white transition" onclick="Modal.closeModal()">Batal</button>
                        <button class="btn btn-primary px-6" onclick="TambahModal.submit()">Konfirmasi</button>
                    </div>
                </div>
            `;
            
            Modal.show(html);

        } catch (err) {
            console.error('Error load paket:', err);
            Toast.error('Gagal memuat daftar paket');
        }
    },

    async submit() {
        const paketId = document.getElementById('tambah-paket').value;
        if (!paketId) return Toast.error('Pilih paket terlebih dahulu');
        
        try {
            await API.sesi.tambahWaktu(this.sesiId, paketId);
            Toast.success('Waktu berhasil ditambahkan ke sesi');
            Modal.closeModal(); 
            
            // Refresh dashboard
            if (typeof Dashboard !== 'undefined') Dashboard.load();
        } catch (err) {
            // Kalau misal kasir nge-hack FE, backend tetep nolak dan pesannya muncul di sini
            Toast.error(err.message);
        }
    }
};