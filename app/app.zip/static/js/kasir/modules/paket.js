// static/js/kasir/modules/paket.js
const Paket = {
    async load() {
        const area = document.getElementById('paket-table');
        if (area) area.innerHTML = '<div class="text-center py-4"><span class="loading"></span> Memuat daftar paket...</div>';

        try {
            const data = await API.paket.list();
            // Menyesuaikan dengan key dari backend (biasanya 'paket' atau 'paket_list')
            const list = data.paket || data.paket_list || [];
            this.render(list);
        } catch (err) {
            console.error("Paket Load Error:", err);
            Toast.error('Gagal memuat paket');
        }
    },

    render(paketList) {
        const container = document.getElementById('paket-table');
        if (!container) return;

        if (!paketList || paketList.length === 0) {
            container.innerHTML = '<div class="text-center text-gray-500 py-10 border border-dashed border-gray-800 rounded">Belum ada paket yang dibuat</div>';
            return;
        }

        container.innerHTML = `
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="text-xs uppercase text-gray-500 border-b border-gray-800">
                            <th class="p-3">Nama Paket</th>
                            <th class="p-3">Grup Target</th>
                            <th class="p-3">Durasi</th>
                            <th class="p-3">Harga</th>
                            <th class="p-3">Masa Aktif</th>
                            <th class="p-3 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm">
                        ${paketList.map(p => `
                            <tr class="border-b border-gray-800/50 hover:bg-gray-800/20 transition">
                                <td class="p-3 font-bold text-gray-200">${p.nama}</td>
                                <td class="p-3">
                                    <span class="px-2 py-0.5 text-[10px] font-bold rounded bg-blue-900/30 text-blue-400 border border-blue-800/50">
                                        ${(p.grup || 'reguler').toUpperCase()}
                                    </span>
                                </td>
                                <td class="p-3 font-mono">${p.durasi_menit} <span class="text-gray-500 text-[10px]">MENIT</span></td>
                                <td class="p-3 text-green-500 font-mono">${Utils.formatRupiah(p.harga)}</td>
                                <td class="p-3 text-gray-400">${p.kadaluarsa_hari} <span class="text-[10px]">HARI</span></td>
                                <td class="p-3 text-right">
                                    <button class="text-blue-500 hover:text-blue-400 mr-3" onclick="Paket.edit(${p.id})">Edit</button>
                                    <button class="text-red-500 hover:text-red-400" onclick="Paket.delete(${p.id})">Hapus</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    },

    async add() {
        const data = {
            nama: document.getElementById('inp-paket-nama').value.trim(),
            grup: document.getElementById('inp-paket-grup').value,
            durasi_menit: parseInt(document.getElementById('inp-paket-durasi').value),
            harga: parseInt(document.getElementById('inp-paket-harga').value),
            kadaluarsa_hari: parseInt(document.getElementById('inp-paket-kadaluarsa').value)
        };

        if (!data.nama) return Toast.error('Nama paket wajib diisi');
        if (isNaN(data.durasi_menit) || data.durasi_menit <= 0) return Toast.error('Durasi tidak valid');
        if (isNaN(data.harga) || data.harga < 0) return Toast.error('Harga tidak valid');

        try {
            await API.paket.create(data);
            Toast.success(`Paket ${data.nama} berhasil dibuat`);
            this.load();
            this.clearForm();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    async edit(id) {
        try {
            // 🟢 DINAMIS: Ambil data paket DAN daftar grup terbaru
            const [paketResponse, grupResponse] = await Promise.all([
                API.paket.list(),
                API.grup.list()
            ]);

            const listPaket = paketResponse.paket || paketResponse.paket_list || [];
            const paket = listPaket.find(p => p.id === id);

            if (!paket) return Toast.error('Paket tidak ditemukan');

            const groups = grupResponse.grup || [];
            this.showEditModal(paket, groups);
        } catch (err) {
            Toast.error('Gagal memuat data edit');
        }
    },

    showEditModal(paket, groups) {
        // 🟢 Generate opsi grup secara dinamis
        const grupOptions = groups.map(g => `
            <option value="${g.nama}" ${paket.grup === g.nama ? 'selected' : ''}>
                ${g.nama.toUpperCase()}
            </option>
        `).join('');

        const formHtml = `
            <div class="p-1">
                <h3 class="text-lg font-bold mb-4 text-blue-400 border-b border-gray-800 pb-2 uppercase">Edit Paket: ${paket.nama}</h3>
                <div class="space-y-4">
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">Nama Paket</label>
                        <input type="text" id="edit-paket-nama" class="form-input" value="${Utils.escapeHtml(paket.nama)}">
                    </div>
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">Grup (Target PC/Member)</label>
                        <select id="edit-paket-grup" class="form-input">
                            ${grupOptions}
                        </select>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-[10px] text-gray-500 uppercase block mb-1">Durasi (Menit)</label>
                            <input type="number" id="edit-paket-durasi" class="form-input font-mono" value="${paket.durasi_menit}">
                        </div>
                        <div>
                            <label class="text-[10px] text-gray-500 uppercase block mb-1">Harga (Rp)</label>
                            <input type="number" id="edit-paket-harga" class="form-input font-mono text-green-500" value="${paket.harga}">
                        </div>
                    </div>
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">Masa Aktif Paket (Hari)</label>
                        <input type="number" id="edit-paket-kadaluarsa" class="form-input" value="${paket.kadaluarsa_hari || 30}">
                        <p class="text-[9px] text-gray-600 mt-1">*Berapa hari saldo waktu ini berlaku setelah dibeli.</p>
                    </div>
                </div>
                <div class="flex gap-2 justify-end mt-6">
                    <button class="px-4 py-2 text-sm text-gray-500 hover:text-white" onclick="Modal.closeModal()">Batal</button>
                    <button class="btn btn-primary px-6" onclick="Paket.doEdit(${paket.id})">Simpan Perubahan</button>
                </div>
            </div>
        `;

        Modal.show(formHtml);
    },

    async doEdit(id) {
        const data = {
            nama: document.getElementById('edit-paket-nama').value.trim(),
            grup: document.getElementById('edit-paket-grup').value,
            durasi_menit: parseInt(document.getElementById('edit-paket-durasi').value),
            harga: parseInt(document.getElementById('edit-paket-harga').value),
            kadaluarsa_hari: parseInt(document.getElementById('edit-paket-kadaluarsa').value)
        };

        if (!data.nama || isNaN(data.durasi_menit) || isNaN(data.harga)) {
            return Toast.error('Lengkapi semua data dengan benar');
        }

        try {
            await API.paket.update(id, data);
            Toast.success('Paket berhasil diperbarui');
            Modal.closeModal();
            this.load();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    async delete(id) {
        Modal.confirm('Hapus paket ini? Paket yang sudah dibeli member tidak akan hilang, tapi tidak bisa dibeli lagi.', async () => {
            try {
                await API.paket.delete(id);
                Toast.success('Paket telah dihapus');
                this.load();
            } catch (err) {
                Toast.error(err.message);
            }
        });
    },

    clearForm() {
        const fields = ['inp-paket-nama', 'inp-paket-durasi', 'inp-paket-harga'];
        fields.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });

        const kadal = document.getElementById('inp-paket-kadaluarsa');
        if (kadal) kadal.value = '30';

        const grup = document.getElementById('inp-paket-grup');
        if (grup) grup.selectedIndex = 0;
    }
};