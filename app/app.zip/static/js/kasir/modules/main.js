// app/static/js/kasir/main.js

const App = {
    currentTab: 'dash',

    async init() {
        // Cek session/login
        const isLoggedIn = await this.checkAuth();
        if (!isLoggedIn) {
            window.location.href = '/kasir/login';
            return;
        }

        // Setup navigasi
        this.setupNavigation();

        // Load tab awal (dashboard)
        await this.loadTabData('dash');

        // Auto refresh dashboard setiap 5 detik
        setInterval(() => {
            if (this.currentTab === 'dash') {
                Dashboard.load();
            }
        }, 5000);
    },

    async checkAuth() {
        try {
            const result = await API.auth.check();
            if (!result.logged_in) {
                return false;
            }
            this.updateUserInfo(result);
            return true;
        } catch (err) {
            console.error('Auth check error:', err);
            return false;
        }
    },

    updateUserInfo(user) {
        const el = document.getElementById('user-info');
        if (el && user.username) {
            el.textContent = user.username;
        }
    },

    setupNavigation() {
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = btn.getAttribute('data-tab');
                if (tab) this.switchTab(tab);
            });
        });
    },

    switchTab(tab) {
        // Update active class pada tombol
        document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
        const activeBtn = document.querySelector(`.nav-btn[data-tab="${tab}"]`);
        if (activeBtn) activeBtn.classList.add('active');

        // Sembunyikan semua konten tab
        document.querySelectorAll('.tab-content').forEach(content => content.classList.add('hidden'));

        // Tampilkan tab yang dipilih
        const targetTab = document.getElementById(`tab-${tab}`);
        if (targetTab) targetTab.classList.remove('hidden');

        this.currentTab = tab;
        this.loadTabData(tab);
    },

    async loadTabData(tab) {
        switch (tab) {
            case 'dash':
                if (typeof Dashboard !== 'undefined') await Dashboard.load();
                break;
            case 'pc':
                if (typeof PC !== 'undefined') await PC.load();
                break;
            case 'paket':
                if (typeof Paket !== 'undefined') await Paket.load();
                break;
            case 'member':
                if (typeof Member !== 'undefined') await Member.load();
                break;
            case 'laporan':
                if (typeof Laporan !== 'undefined') await Laporan.load();
                break;
            case 'log':
                if (typeof Log !== 'undefined') await Log.load();
                break;
            default:
                console.warn('Unknown tab:', tab);
        }
    },

    async logout() {
        const confirmed = confirm('Yakin ingin logout?');
        if (!confirmed) return;
        try {
            await API.auth.logout();
            Toast.success('Logout berhasil');
            window.location.href = '/kasir/login';
        } catch (err) {
            Toast.error('Logout gagal: ' + err.message);
        }
    }
};

// Start aplikasi saat DOM siap
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

// Ekspos global untuk keperluan inline onclick (jika ada)
window.App = App;