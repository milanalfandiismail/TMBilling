const Log = {
    async load(filter = '') {
        try {
            const data = await API.report.logs(filter, 500);
            this.render(data.logs);
        } catch (err) {
            Toast.error('Gagal memuat log');
        }
    },
    render(logs) {
        const container = document.getElementById('log-content');
        if (!logs.length) {
            container.innerHTML = '<div class="text-center text-gray-500 py-4">Tidak ada log</div>';
            return;
        }
        container.innerHTML = logs.map(line => `<div class="border-b border-gray-800 py-1 px-2 font-mono text-xs text-gray-400">${Utils.escapeHtml(line)}</div>`).join('');
    },
    filter() {
        const filter = document.getElementById('filter-log').value.trim();
        this.load(filter);
    },
    async clear() {
        Modal.confirm('Yakin membersihkan semua log?', async () => {
            try {
                await API.report.clearLogs();
                Toast.success('Log dibersihkan');
                this.load();
            } catch (err) {
                Toast.error(err.message);
            }
        });
    },
    exportLogs() {
        const filter = document.getElementById('filter-log').value.trim();
        const url = API.report.exportLogsUrl(filter);
        window.open(url, '_blank');
    }
};