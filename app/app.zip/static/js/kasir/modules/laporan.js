const Laporan = {
    async load() {
        try {
            const data = await API.report.harian();
            this.render(data);
        } catch (err) {
            Toast.error('Gagal memuat laporan');
        }
    },
    render(data) {
        const container = document.getElementById('laporan-area');
        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-[#1a1a1a] border border-gray-800 rounded p-4 text-center">
                    <div class="text-2xl font-bold text-green-400">${Utils.formatRupiah(data.total_pendapatan)}</div>
                    <div class="text-xs text-gray-500 uppercase mt-1">Pendapatan Hari Ini</div>
                </div>
                <div class="bg-[#1a1a1a] border border-gray-800 rounded p-4 text-center">
                    <div class="text-2xl font-bold text-blue-400">${data.total_sesi}</div>
                    <div class="text-xs text-gray-500 uppercase mt-1">Total Sesi</div>
                </div>
                <div class="bg-[#1a1a1a] border border-gray-800 rounded p-4 text-center">
                    <div class="text-2xl font-bold text-yellow-400">${data.sesi_aktif}</div>
                    <div class="text-xs text-gray-500 uppercase mt-1">Sesi Aktif</div>
                </div>
            </div>
            <div class="mt-4 text-center text-xs text-gray-500">Tanggal: ${data.tanggal}</div>
        `;
    }
};