// static/js/kasir/modules/grup.js

const Grup = {
    // 1. Load data grup dari backend
    async load() {
        const area = document.getElementById('grup-table');
        // 🟢 Jangan tampilkan "Loading" di tabel kalau elemennya sedang hidden
        if (area && !area.closest('.tab-content').classList.contains('hidden')) {
            area.innerHTML = '<div class="text-center py-4"><span class="loading"></span> Memuat...</div>';
        }

        try {
            const data = await API.grup.list();
            const list = data.grup || data.grup_list || [];

            // 🟢 Selalu update dropdown, mau tabelnya kelihatan atau nggak
            this.updateAllDropdowns(list);

            // 🟢 Render tabel hanya jika elemennya ada di DOM
            if (area) {
                this.render(list);
            }
        } catch (err) {
            console.error("Grup Load Error:", err);
        }
    },

    // 2. Tambah Grup Baru
    async add() {
        const namaInp = document.getElementById('inp-grup-nama');
        const ketInp = document.getElementById('inp-grup-ket');

        const data = {
            nama: namaInp.value.trim(),
            keterangan: ketInp.value.trim()
        };

        if (!data.nama) return Toast.error("Nama grup wajib diisi");

        try {
            // Kirim ke GrupService.create di backend
            await API.grup.create(data);
            Toast.success(`Grup ${data.nama} berhasil disimpan`);

            // Reset Form
            namaInp.value = '';
            ketInp.value = '';

            // Refresh data
            this.load();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    // 3. Hapus Grup (dengan proteksi backend)
    async delete(id, nama) {
        Modal.confirm(`Hapus grup "${nama.toUpperCase()}"? Tindakan ini akan gagal jika grup masih digunakan oleh PC/Member.`, async () => {
            try {
                // GrupService.delete akan mengecek relasi sebelum menghapus
                await API.grup.delete(id);
                Toast.success("Grup berhasil dihapus");
                this.load();
            } catch (err) {
                // Menampilkan error jika grup masih ada isinya
                Toast.error(err.message);
            }
        });
    },

    // 4. Update semua <select> grup di tab PC, Paket, dan Member
    updateAllDropdowns(list) {
        const options = list.map(g => `<option value="${g.nama}">${g.nama.toUpperCase()}</option>`).join('');
        const targets = ['inp-pc-grup', 'inp-batch-grup', 'inp-paket-grup', 'inp-mem-grup'];

        targets.forEach(id => {
            const el = document.getElementById(id);
            if (el) el.innerHTML = options;
        });
    },

    // 5. Render Tabel ke HTML
    render(list) {
        const area = document.getElementById('grup-table');
        if (list.length === 0) {
            area.innerHTML = '<div class="text-center text-gray-500 py-4">Belum ada grup. Buat "reguler" sebagai grup pertama.</div>';
            return;
        }

        let html = `<table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Kategori</th>
                    <th>Keterangan</th>
                    <th class="text-right">Aksi</th>
                </tr>
            </thead>
            <tbody>`;

        list.forEach(g => {
            html += `
                <tr>
                    <td class="text-gray-600 font-mono text-[10px]">${g.id}</td>
                    <td>
                        <span class="bg-[#2a2a2a] text-white px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider">
                            ${g.nama}
                        </span>
                    </td>
                    <td class="text-gray-400 text-xs">${g.keterangan || '-'}</td>
                    <td class="text-right">
                        <button class="btn btn-danger py-0.5 px-2" onclick="Grup.delete(${g.id}, '${g.nama}')">Hapus</button>
                    </td>
                </tr>`;
        });

        html += `</tbody></table>`;
        area.innerHTML = html;
    }
};