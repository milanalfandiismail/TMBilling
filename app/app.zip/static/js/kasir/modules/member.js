// static/js/kasir/modules/member.js
const Member = {
    allMembers: [], // Simpan data untuk fitur pencarian

    async load() {
        const area = document.getElementById('member-table');
        if (area) area.innerHTML = '<div class="text-center py-4"><span class="loading"></span> Memuat data member...</div>';
        
        try {
            const [memberData, grupData] = await Promise.all([
                API.member.list(),
                API.grup.list()
            ]);

            this.allMembers = memberData.members || memberData.member_list || [];
            const groups = grupData.grup || grupData || [];

            const addGrupSelect = document.getElementById('inp-mem-grup');
            if (addGrupSelect) {
                addGrupSelect.innerHTML = groups.map(g => 
                    `<option value="${g.nama}">${g.nama.toUpperCase()}</option>`
                ).join('');
            }

            this.render(this.allMembers);
        } catch (err) {
            console.error("Member Load Error:", err);
            Toast.error('Gagal memuat member');
        }
    },

    // 🟢 Fitur Pencarian
    search(query) {
        const q = query.toLowerCase();
        const filtered = this.allMembers.filter(m => 
            m.username.toLowerCase().includes(q) || 
            (m.nama_lengkap && m.nama_lengkap.toLowerCase().includes(q))
        );
        this.render(filtered);
    },

    render(members) {
        const container = document.getElementById('member-table');
        if (!container) return;

        if (!members || members.length === 0) {
            container.innerHTML = '<div class="text-center text-gray-500 py-10 border border-dashed border-gray-800 rounded">Data member tidak ditemukan</div>';
            return;
        }

        container.innerHTML = `
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="text-xs uppercase text-gray-500 border-b border-gray-800">
                        <th class="p-3">Username</th>
                        <th class="p-3">Nama</th>
                        <th class="p-3">Grup</th>
                        <th class="p-3">Waktu</th>
                        <th class="p-3 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody class="text-sm">
                    ${members.map(m => {
                        const grupNama = (typeof m.grup === 'object' ? m.grup.nama : m.grup) || 'reguler';
                        return `
                        <tr class="border-b border-gray-800/50 hover:bg-gray-800/20 transition">
                            <td class="p-3 font-mono text-blue-400">${m.username}</td>
                            <td class="p-3">${m.nama_lengkap || '-'}</td>
                            <td class="p-3">
                                <span class="px-2 py-0.5 text-[10px] font-bold rounded bg-gray-900 border border-gray-700">
                                    ${grupNama.toUpperCase()}
                                </span>
                            </td>
                            <td class="p-3 font-mono text-green-500">${Utils.formatMenit(m.waktu_tersimpan)}</td>
                            <td class="p-3 text-right">
                                <button class="text-gray-400 hover:text-white p-1 mx-1" onclick="Member.showDetail(${m.id})" title="Detail Lengkap">
                                    Detail
                                </button>
                                <button class="text-blue-500 hover:text-blue-400 p-1 mx-1" onclick="Member.edit(${m.id})">
                                    Edit
                                </button>
                                <button class="text-green-500 hover:text-green-400 p-1 mx-1" onclick="Member.tambahWaktu(${m.id})">
                                    +Waktu
                                </button>
                                <button class="text-red-500 hover:text-red-400 p-1 mx-1" onclick="Member.delete(${m.id})">
                                    Hapus
                                </button>
                            </td>
                        </tr>
                    `}).join('')}
                </tbody>
            </table>
        </div>
        `;
    },

    // 🟢 Fitur Detail Member (Nampilin info jelas di modal)
    showDetail(id) {
        const member = this.allMembers.find(m => m.id === id);
        if (!member) return Toast.error('Data tidak ditemukan');

        const grupNama = (typeof member.grup === 'object' ? member.grup.nama : member.grup) || 'reguler';
        
        const detailHtml = `
            <div class="p-2">
                <h3 class="text-lg font-bold mb-4 border-b border-gray-800 pb-2 text-green-500 uppercase tracking-widest">Detail Member</h3>
                <div class="grid grid-cols-1 gap-3 text-sm">
                    <div class="flex justify-between border-b border-gray-800/50 py-2">
                        <span class="text-gray-500">ID Member</span>
                        <span class="font-mono text-gray-300">#${member.id}</span>
                    </div>
                    <div class="flex justify-between border-b border-gray-800/50 py-2">
                        <span class="text-gray-500">Username</span>
                        <span class="font-bold text-blue-400">${member.username}</span>
                    </div>
                    <div class="flex justify-between border-b border-gray-800/50 py-2">
                        <span class="text-gray-500">Nama Lengkap</span>
                        <span class="text-gray-200">${member.nama_lengkap || '-'}</span>
                    </div>
                    <div class="flex justify-between border-b border-gray-800/50 py-2">
                        <span class="text-gray-500">Grup / Level</span>
                        <span class="px-2 py-0.5 rounded bg-gray-800 text-xs font-bold border border-gray-700">${grupNama.toUpperCase()}</span>
                    </div>
                    <div class="flex justify-between border-b border-gray-800/50 py-2">
                        <span class="text-gray-500">Sisa Saldo Waktu</span>
                        <span class="font-mono text-green-500 font-bold">${Utils.formatMenit(member.waktu_tersimpan)}</span>
                    </div>
                    <div class="flex justify-between border-b border-gray-800/50 py-2">
                        <span class="text-gray-500">Masa Aktif S/D</span>
                        <span class="text-gray-300">${Utils.formatTanggal(member.kadaluarsa_pada)}</span>
                    </div>
                    <div class="flex justify-between border-b border-gray-800/50 py-2">
                        <span class="text-gray-500">Email</span>
                        <span class="text-gray-400">${member.email || '-'}</span>
                    </div>
                    <div class="flex justify-between border-b border-gray-800/50 py-2">
                        <span class="text-gray-500">No. HP / WA</span>
                        <span class="text-gray-400">${member.no_hp || '-'}</span>
                    </div>
                    <div class="flex justify-between py-2">
                        <span class="text-gray-500">Status Akun</span>
                        <span>${member.aktif ? '<b class="text-green-500">AKTIF</b>' : '<b class="text-red-500">NONAKTIF</b>'}</span>
                    </div>
                </div>
                <div class="mt-6 flex justify-end">
                    <button class="btn btn-secondary px-6" onclick="Modal.closeModal()">Tutup</button>
                </div>
            </div>
        `;
        Modal.show(detailHtml);
    },

    async add() {
        const data = {
            username: document.getElementById('inp-mem-user').value.trim(),
            password: document.getElementById('inp-mem-pass').value,
            nama_lengkap: document.getElementById('inp-mem-nama').value.trim(),
            email: document.getElementById('inp-mem-email').value.trim(),
            no_hp: document.getElementById('inp-mem-nohp').value.trim(),
            grup: document.getElementById('inp-mem-grup').value
        };

        if (!data.username || !data.password) return Toast.error('Username dan password wajib diisi');
        
        try {
            await API.member.create(data);
            Toast.success(`Member ${data.username} berhasil didaftarkan`);
            this.load();
            this.clearForm();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    async edit(id) {
        try {
            const [memberData, grupData] = await Promise.all([
                API.member.list(),
                API.grup.list()
            ]);

            const members = memberData.members || memberData.member_list || [];
            const member = members.find(m => m.id === id);
            if (!member) return Toast.error('Member tidak ditemukan');
            
            const groups = grupData.grup || grupData || []; 
            this.showEditModal(member, groups);
        } catch (err) {
            Toast.error('Gagal mengambil data untuk edit');
        }
    },

    showEditModal(member, groups) {
        const currentGrup = (typeof member.grup === 'object' ? member.grup.nama : member.grup) || 'reguler';
        const grupOptions = groups.map(g => `
            <option value="${g.nama}" ${currentGrup === g.nama ? 'selected' : ''}>
                ${g.nama.toUpperCase()}
            </option>
        `).join('');

        const formHtml = `
            <div class="p-1">
                <h3 class="text-lg font-bold mb-4 border-b border-gray-800 pb-2 text-blue-400 uppercase">Edit: ${member.username}</h3>
                <div class="grid grid-cols-1 gap-4">
                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="text-[10px] text-gray-500 uppercase block mb-1">Nama Lengkap</label>
                            <input type="text" id="edit-member-nama" class="form-input" value="${Utils.escapeHtml(member.nama_lengkap || '')}">
                        </div>
                        <div>
                            <label class="text-[10px] text-gray-500 uppercase block mb-1">Grup Member</label>
                            <select id="edit-member-grup" class="form-input">${grupOptions}</select>
                        </div>
                    </div>
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">Email</label>
                        <input type="email" id="edit-member-email" class="form-input" value="${member.email || ''}">
                    </div>
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">No HP</label>
                        <input type="text" id="edit-member-nohp" class="form-input" value="${member.no_hp || ''}">
                    </div>
                    <div class="pt-2 mt-2 border-t border-gray-800 text-[10px] text-yellow-600 uppercase">Ganti Password (Biarkan kosong jika tidak diubah)</div>
                    <input type="password" id="edit-member-password" class="form-input">
                </div>
                <div class="flex gap-2 justify-end mt-6">
                    <button class="px-4 py-2 text-sm text-gray-400" onclick="Modal.closeModal()">Batal</button>
                    <button class="btn btn-primary px-6" onclick="Member.doEdit(${member.id})">Simpan</button>
                </div>
            </div>
        `;
        Modal.show(formHtml);
    },

    async doEdit(id) {
        const data = {
            nama_lengkap: document.getElementById('edit-member-nama').value.trim(),
            email: document.getElementById('edit-member-email').value.trim(),
            no_hp: document.getElementById('edit-member-nohp').value.trim(),
            grup: document.getElementById('edit-member-grup').value,
        };
        const password = document.getElementById('edit-member-password').value;
        if (password) data.password = password;

        try {
            await API.member.update(id, data);
            Toast.success('Berhasil diperbarui');
            Modal.closeModal();
            this.load();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    async delete(id) {
        Modal.confirm('Hapus member permanen?', async () => {
            try {
                await API.member.delete(id);
                Toast.success('Member dihapus');
                this.load();
            } catch (err) {
                Toast.error(err.message);
            }
        });
    },

    async tambahWaktu(memberId) {
        try {
            const member = this.allMembers.find(m => m.id === memberId);
            const mGrup = (typeof member.grup === 'object' ? member.grup.nama : member.grup) || 'reguler';

            const paketData = await API.paket.list({ aktif_only: true });
            const paketListFull = paketData.paket || paketData.paket_list || [];
            
            const paketList = paketListFull.filter(p => {
                const pGrup = (typeof p.grup === 'object' ? p.grup.nama : p.grup) || 'reguler';
                return pGrup.toLowerCase() === mGrup.toLowerCase();
            });
            
            if (!paketList.length) return Toast.error(`Tidak ada paket aktif untuk ${mGrup.toUpperCase()}`);

            const options = paketList.map(p => `
                <option value="${p.id}">${p.nama} (${p.durasi_menit}m) - ${Utils.formatRupiah(p.harga)}</option>
            `).join('');

            Modal.show(`
                <div class="p-1">
                    <h3 class="text-sm font-bold uppercase mb-4 text-green-500">Tambah Saldo: ${member.username}</h3>
                    <select id="tambah-waktu-paket" class="form-input mb-4">${options}</select>
                    <div class="flex gap-2 justify-end">
                        <button class="btn btn-secondary" onclick="Modal.closeModal()">Batal</button>
                        <button class="btn btn-primary" onclick="Member.doAddWaktu(${memberId})">Bayar</button>
                    </div>
                </div>
            `);
        } catch (err) {
            Toast.error('Gagal muat paket');
        }
    },

    async doAddWaktu(memberId) {
        const select = document.getElementById('tambah-waktu-paket');
        if (!select) return;
        try {
            await API.member.tambahWaktu(memberId, select.value);
            Toast.success('Saldo ditambahkan');
            Modal.closeModal();
            this.load();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    clearForm() {
        ['inp-mem-user', 'inp-mem-pass', 'inp-mem-nama', 'inp-mem-email', 'inp-mem-nohp'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
    }
};