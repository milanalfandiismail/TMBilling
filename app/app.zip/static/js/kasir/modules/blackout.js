// static/js/kasir/modules/blackout.js

const Blackout = {
    currentDate: null,

    async load() {
        await this.loadDates();
    },

    async loadDates() {
        try {
            const data = await API.blackout.dates();
            const dates = data.dates || [];
            this.renderDatePicker(dates);

            if (dates.length > 0) {
                this.currentDate = dates[0];
                await this.loadList(dates[0]);
            } else {
                this.renderEmpty();
            }
        } catch (err) {
            console.error("Blackout load error:", err);
        }
    },

    renderDatePicker(dates) {
        const el = document.getElementById('blackout-date-picker');
        if (!el) return;
        if (dates.length === 0) {
            el.innerHTML = '<option value="">— Belum ada data —</option>';
            return;
        }
        el.innerHTML = dates.map(d => `<option value="${d}">${d}</option>`).join('');
        el.onchange = () => this.loadList(el.value);
    },

    async loadList(date) {
        this.currentDate = date;
        const area = document.getElementById('blackout-list');
        if (!area) return;
        area.innerHTML = '<div class="text-center py-6"><span class="loading"></span> Memuat...</div>';

        try {
            const data = await API.blackout.list(date);
            this.renderList(data.data || []);
        } catch (err) {
            area.innerHTML = '<div class="text-center text-gray-500 py-6">Gagal memuat data</div>';
        }
    },

    renderEmpty() {
        const area = document.getElementById('blackout-list');
        if (!area) return;
        area.innerHTML = `
            <div class="text-center py-16 text-gray-600">
                <div class="text-5xl mb-3">⚡</div>
                <div class="text-sm text-gray-500">Belum ada riwayat blackout</div>
                <div class="text-xs mt-2 text-gray-700">Klik tombol <b>"Deteksi Blackout"</b> untuk mulai scan</div>
            </div>`;
    },

    renderList(list) {
        const area = document.getElementById('blackout-list');
        if (!area) return;

        if (list.length === 0) {
            area.innerHTML = '<div class="text-center text-gray-600 py-10">Tidak ada sesi blackout pada tanggal ini</div>';
            return;
        }

        const pending = list.filter(s => !s.is_blackout_resolved);
        const resolved = list.filter(s => s.is_blackout_resolved);

        let html = '';

        if (pending.length > 0) {
            html += `
                <div class="mb-2 text-[10px] text-yellow-500 uppercase tracking-widest font-bold">
                    ⏳ Menunggu Tindakan (${pending.length})
                </div>`;
            pending.forEach(s => { html += this.renderCard(s); });
        }

        if (resolved.length > 0) {
            html += `
                <div class="mt-6 mb-2 text-[10px] text-green-600 uppercase tracking-widest font-bold">
                    ✅ Sudah Diselesaikan (${resolved.length})
                </div>`;
            resolved.forEach(s => { html += this.renderCard(s, true); });

            html += `
                <div class="mt-4 flex justify-end">
                    <button class="btn btn-danger text-[10px]" onclick="Blackout.clearResolved()">
                        🗑️ Hapus Record Selesai (${resolved.length})
                    </button>
                </div>`;
        }

        area.innerHTML = html;
    },

    renderCard(s, resolved = false) {
        const isMember = s.tipe === 'member';
        const borderColor = resolved ? 'border-gray-800' : (isMember ? 'border-blue-800/50' : 'border-yellow-800/50');
        const badgeColor = isMember ? 'bg-blue-900/30 text-blue-400' : 'bg-yellow-900/30 text-yellow-400';

        let aksiHtml = '';
        if (!resolved) {
            if (isMember) {
                aksiHtml = `
                    <button class="btn btn-primary text-[10px] px-4"
                        onclick="Blackout.resolveMember(${s.id}, '${s.username}', ${s.sisa_waktu_mati})">
                        💰 Kembalikan ${s.sisa_waktu_mati}m ke Saldo
                    </button>`;
            } else {
                aksiHtml = `
                    <div class="flex gap-2 flex-wrap">
                        <button class="btn btn-primary text-[10px]"
                            onclick="Blackout.resolveGuestSama(${s.id}, '${s.username}')">
                            🔄 Lanjut di PC Ini
                        </button>
                        <button class="btn btn-primary text-[10px]"
                            onclick="Blackout.showLanjutModal(${s.id}, '${s.username}')">
                            🔄 Lanjut di PC Lain
                        </button>
                        <button class="btn btn-danger text-[10px]"
                            onclick="Blackout.resolveGuestTutup(${s.id}, '${s.username}')">
                            ✖ Tutup Saja
                        </button>
                    </div>`;
            }
        } else {
            aksiHtml = `<span class="text-[10px] text-green-600">✅ Selesai</span>`;
        }

        return `
            <div class="bg-[#141414] border ${borderColor} rounded p-4 mb-3">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <span class="text-[10px] font-bold px-2 py-0.5 rounded ${badgeColor}">
                            ${isMember ? '👤 MEMBER' : '🎮 GUEST'}
                        </span>
                        <span class="ml-2 font-mono font-bold text-white">${s.username}</span>
                        <span class="ml-2 text-gray-500 text-xs">— PC ${s.pc_kode}</span>
                    </div>
                    <div class="text-right text-xs text-gray-500">
                        Mati: <span class="text-yellow-500 font-mono">${s.jam_mati}</span>
                    </div>
                </div>
                <div class="flex items-center justify-between">
                    <div class="text-sm">
                        Sisa waktu saat mati: 
                        <span class="font-mono font-bold text-green-400">${Utils.formatMenit(s.sisa_waktu_mati)}</span>
                    </div>
                    ${aksiHtml}
                </div>
            </div>`;
    },

    async deteksi() {
        const btn = document.getElementById('btn-deteksi');
        if (btn) { btn.disabled = true; btn.textContent = '🔍 Mendeteksi...'; }

        try {
            const result = await API.blackout.deteksi();
            if (result.total > 0) {
                Toast.success(result.message);
                await this.loadDates();
            } else {
                Toast.success('Tidak ada sesi blackout terdeteksi saat ini');
            }
        } catch (err) {
            Toast.error('Gagal deteksi: ' + err.message);
        } finally {
            if (btn) { btn.disabled = false; btn.textContent = '🔍 Deteksi Blackout'; }
        }
    },

    async resolveMember(sesiId, username, sisa) {
        Modal.confirm(
            `Kembalikan ${sisa} menit ke saldo member "${username}"? Sesi akan ditutup.`,
            async () => {
                try {
                    const result = await API.blackout.resolveMember(sesiId);
                    Toast.success(result.message);
                    await this.loadList(this.currentDate);
                } catch (err) {
                    Toast.error(err.message);
                }
            }
        );
    },

    async resolveGuestSama(sesiId, namaGuest) {
        Modal.confirm(
            `Lanjutkan sesi guest "${namaGuest}" di PC yang sama?`,
            async () => {
                try {
                    const result = await API.blackout.resolveGuestSama(sesiId);
                    Toast.success(result.message);
                    await this.loadList(this.currentDate);
                } catch (err) {
                    Toast.error(err.message);
                }
            }
        );
    },

    async showLanjutModal(sesiId, namaGuest) {
        try {
            const data = await API.pc.list();
            const kosong = (data.pc_list || []).filter(p => p.status === 'kosong');

            if (kosong.length === 0) {
                return Toast.error('Tidak ada PC kosong saat ini');
            }

            const options = kosong.map(p =>
                `<option value="${p.id}">${p.kode} — ${p.nama || p.kode} (${p.grup})</option>`
            ).join('');

            Modal.show(`
                <div class="p-1">
                    <h3 class="text-sm font-bold uppercase mb-4 text-blue-400 border-b border-gray-800 pb-2">
                        Lanjutkan Sesi: ${namaGuest}
                    </h3>
                    <div class="mb-4">
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">Pilih PC Tujuan</label>
                        <select id="lanjut-pc-id" class="form-input">${options}</select>
                    </div>
                    <p class="text-[11px] text-gray-600 mb-4">
                        Sesi baru akan dibuat di PC yang dipilih dengan sisa waktu yang tersimpan saat mati lampu.
                    </p>
                    <div class="flex gap-2 justify-end">
                        <button class="btn btn-secondary" onclick="Modal.closeModal()">Batal</button>
                        <button class="btn btn-primary px-6" onclick="Blackout.doLanjut(${sesiId})">Lanjutkan</button>
                    </div>
                </div>
            `);
        } catch (err) {
            Toast.error('Gagal memuat daftar PC');
        }
    },

    async doLanjut(sesiId) {
        const pcId = document.getElementById('lanjut-pc-id')?.value;
        if (!pcId) return Toast.error('Pilih PC terlebih dahulu');
        try {
            const result = await API.blackout.resolveGuestLanjut(sesiId, parseInt(pcId));
            Toast.success(result.message);
            Modal.closeModal();
            await this.loadList(this.currentDate);
        } catch (err) {
            Toast.error(err.message);
        }
    },

    async resolveGuestTutup(sesiId, namaGuest) {
        Modal.confirm(
            `Tutup sesi guest "${namaGuest}" tanpa kompensasi? Tindakan ini tidak bisa dibatalkan.`,
            async () => {
                try {
                    const result = await API.blackout.resolveGuestTutup(sesiId);
                    Toast.success(result.message);
                    await this.loadList(this.currentDate);
                } catch (err) {
                    Toast.error(err.message);
                }
            }
        );
    },

    async clearResolved() {
        if (!this.currentDate) return;
        Modal.confirm(
            `Hapus semua record yang sudah selesai pada ${this.currentDate}?`,
            async () => {
                try {
                    const result = await API.blackout.clearResolved(this.currentDate);
                    Toast.success(result.message);
                    await this.loadDates();
                } catch (err) {
                    Toast.error(err.message);
                }
            }
        );
    },


    async forceAllAndDetect() {
        if (!confirm('⚠️ PERINGATAN ⚠️\n\nTombol ini digunakan hanya saat MATI LAMPU TOTAL!\n\nSemua sesi aktif akan DITUTUP dan masuk BLACKOUT.\n\nLANJUTKAN?')) return;

        try {
            const result = await API.blackout.forceAllAndDetect();
            Toast.success(result.message);
            if (typeof Dashboard !== 'undefined') await Dashboard.load();
            const blackoutBtn = document.querySelector('.nav-btn[data-tab="blackout"]');
            if (blackoutBtn) blackoutBtn.click();
            await this.loadDates();
        } catch (err) {
            Toast.error(err.message);
        }
    }

};

window.Blackout = Blackout;