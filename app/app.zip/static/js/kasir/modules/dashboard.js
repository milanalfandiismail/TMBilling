// static/js/kasir/modules/dashboard.js
const Dashboard = {
    refreshInterval: null,

    async load() {
        try {
            const data = await API.dashboard.pcList();
            this.render(data);
            this.updateStats();
            this.attachEvents();
        } catch (err) {
            console.error('Dashboard load error:', err);
            document.getElementById('pc-area').innerHTML =
                '<div class="text-center text-red-500 py-10">Gagal memuat data PC</div>';
        }
    },

    render(data) {
        let html = '';
        let totalAktif = 0;

        const availableGroups = Object.keys(data.by_grup || {});

        if (availableGroups.length === 0) {
            document.getElementById('pc-area').innerHTML =
                '<div class="text-center text-gray-500 py-10">Belum ada PC terdaftar di grup mana pun</div>';
            return;
        }

        availableGroups.forEach(grupName => {
            const pcs = data.by_grup[grupName] || [];
            if (pcs.length === 0) return;

            const aktif = pcs.filter(p => p.status === 'terpakai' && p.sesi_detail?.sisa_menit > 0).length;
            totalAktif += aktif;

            html += `
                <div class="mb-6">
                    <div class="flex justify-between text-xs text-gray-500 uppercase mb-2 pb-1 border-b border-gray-800">
                        <span class="font-bold tracking-widest">${grupName.toUpperCase()}</span>
                        <span>${aktif}/${pcs.length} aktif</span>
                    </div>
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-7 2xl:grid-cols-8 gap-4">
                        ${pcs.map(pc => this.renderCard(pc)).join('')}
                    </div>
                </div>
            `;
        });

        document.getElementById('pc-area').innerHTML = html;
        this.adjustRefreshRate(totalAktif);
    },

    renderCard(pc) {
        const sesi = pc.sesi_detail;
        const isActive = pc.status === 'terpakai' && sesi && sesi.sisa_menit > 0;

        const borderClass = isActive ? 'border-2 border-green-500 bg-green-900/10' : 'border border-gray-700';
        const nameClass = isActive ? 'text-green-400' : 'text-white';

        let indicatorClass = 'bg-gray-600';
        let indicatorTitle = 'PC Offline';

        if (pc.online) {
            if (isActive) {
                indicatorClass = 'bg-green-500 animate-pulse';
                indicatorTitle = 'Online - Digunakan';
            } else {
                indicatorClass = 'bg-yellow-500';
                indicatorTitle = 'Online - Kosong';
            }
        }

        return `
        <div class="pc-card bg-[#1a1a1a] rounded p-3 transition-all ${borderClass} ${!isActive ? 'cursor-pointer hover:border-gray-500' : ''}" 
             data-pc-kode="${pc.kode}"
             onclick="${isActive ? '' : `BukaModal.open('${pc.kode}', '${pc.grup}')`}"> 
            
            <div class="flex justify-between items-start">
                <span class="font-mono font-bold ${nameClass}">${pc.kode}</span>
                <span class="w-2.5 h-2.5 rounded-full ${indicatorClass}" title="${indicatorTitle}"></span>
            </div>
            
            <div class="text-xs text-gray-400 mt-1">${pc.nama || pc.kode}</div>
            <div class="text-xs text-gray-500 font-mono">${pc.ip_address || '-'}</div>
            
            ${isActive && sesi ? this.renderSession(sesi, pc.grup) : `
                <button class="w-full mt-3 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700 transition"
                    onclick="event.stopPropagation(); BukaModal.open('${pc.kode}', '${pc.grup}')">Buka Sesi</button>
            `}
        </div>`;
    },

    // 🟢 FIX 2: Tambahkan parameter pcGrup di sini
    renderSession(sesi, pcGrup) {
        const nama = sesi.member_nama || sesi.nama_guest || 'Guest';
        const warning = sesi.sisa_menit <= 5;
        return `
            <div class="mt-3 pt-2 border-t border-gray-800">
                <div class="text-[10px] text-gray-500 uppercase">${sesi.tipe === 'member' ? 'MEMBER' : 'GUEST'}</div>
                <div class="text-lg font-mono font-bold ${warning ? 'text-red-500' : 'text-green-400'}">
                    ${Utils.formatMenit(sesi.sisa_menit)}
                </div>
                <div class="text-[11px] text-gray-400 truncate" title="${nama}">${nama}</div>
                <div class="flex gap-1 mt-2">
                    <button class="stop-btn flex-1 py-1 text-[10px] border border-red-500 text-red-500 rounded hover:bg-red-500 hover:text-white transition"
                        data-sesi-id="${sesi.id}">Stop</button>
                    
                    <button class="tambah-btn flex-1 py-1 text-[10px] bg-gray-800 border border-gray-600 rounded hover:bg-gray-700 transition"
                        data-sesi-id="${sesi.id}"
                        data-grup="${pcGrup || 'reguler'}">+Waktu</button>
                    
                    <button class="pindah-btn flex-1 py-1 text-[10px] bg-blue-800 border border-blue-600 rounded hover:bg-blue-700 transition"
                        data-sesi-id="${sesi.id}" 
                        data-tipe="${sesi.tipe}" 
                        data-grup="${pcGrup || 'reguler'}">Pindah</button>
                </div>
            </div>`;
    },

    attachEvents() {
        // Stop Sesi
        document.querySelectorAll('.stop-btn').forEach(btn => {
            btn.onclick = (e) => {
                e.stopPropagation();
                this.stopSesi(btn.dataset.sesiId);
            };
        });

        // Tambah Waktu
        document.querySelectorAll('.tambah-btn').forEach(btn => {
            btn.onclick = (e) => {
                e.stopPropagation();
                // 🟢 FIX 4: Kirim dataset.grup ke fungsi tambahWaktu
                this.tambahWaktu(btn.dataset.sesiId, btn.dataset.grup);
            };
        });

        // Pindah PC
        document.querySelectorAll('.pindah-btn').forEach(btn => {
            btn.onclick = (e) => {
                e.stopPropagation();
                this.pindahPc(btn.dataset.sesiId, btn.dataset.tipe, btn.dataset.grup);
            };
        });
    },

    async stopSesi(sesiId) {
        Modal.confirm('Yakin tutup sesi ini?', async () => {
            try {
                await API.sesi.tutup(sesiId);
                Toast.success('Sesi ditutup');
                this.load();
            } catch (err) { Toast.error(err.message); }
        });
    },

    // 🟢 FIX 5: Terima pcGrup dan kirim ke TambahModal
    async tambahWaktu(sesiId, pcGrup) {
        if (typeof TambahModal !== 'undefined') TambahModal.open(sesiId, pcGrup);
        else Toast.error('Modal tambah waktu tidak tersedia');
    },

    async pindahPc(sesiId, tipe, pcGrup) {
        try {
            const data = await API.pc.list();

            // FILTER GANDA: Harus kosong DAN grupnya harus sama dengan PC asal
            const kosong = data.pc_list.filter(p => p.status === 'kosong' && p.grup === pcGrup);

            if (kosong.length === 0) return Toast.error(`Tidak ada PC kosong di area ${pcGrup.toUpperCase()}`);

            const options = kosong.map(p => `<option value="${p.kode}">${p.kode} - ${p.nama}</option>`).join('');

            Modal.show(`
                <div class="p-1">
                    <h3 class="text-sm uppercase mb-4 font-bold text-blue-400 border-b border-gray-800 pb-2">
                        Pindah PC <span class="text-gray-500">(${pcGrup.toUpperCase()})</span>
                    </h3>
                    <div class="mb-5">
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">Pilih PC Tujuan</label>
                        <select id="pindah-pc-target" class="form-input bg-gray-900 border-gray-700 w-full">${options}</select>
                    </div>
                    <div class="flex gap-2 justify-end mt-6">
                        <button class="px-4 py-2 text-sm text-gray-400 hover:text-white transition" onclick="Modal.closeModal()">Batal</button>
                        <button class="btn btn-primary px-6" onclick="Dashboard.doPindahPc(${sesiId})">Pindahkan</button>
                    </div>
                </div>`);
        } catch (err) { Toast.error('Gagal memuat daftar PC'); }
    },

    async doPindahPc(sesiId) {
        const pcKode = document.getElementById('pindah-pc-target')?.value;
        if (!pcKode) return;
        try {
            await API.sesi.pindahPC(sesiId, pcKode);
            Toast.success('Berhasil pindah PC');
            Modal.closeModal();
            this.load();
        } catch (err) { Toast.error(err.message); }
    },

    async updateStats() {
        try {
            const data = await API.report.harian();
            document.getElementById('stat-active').innerText = data.sesi_aktif || 0;
            document.getElementById('stat-income').innerText = (data.total_pendapatan || 0).toLocaleString('id-ID');
        } catch (err) { console.error('Stats error:', err); }
    },

    adjustRefreshRate(activeCount) {
        if (this.refreshInterval) clearInterval(this.refreshInterval);
        const interval = activeCount > 0 ? 3000 : 10000;
        this.refreshInterval = setInterval(() => this.load(), interval);
    }
};