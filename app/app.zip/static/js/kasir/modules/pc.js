// static/js/kasir/modules/pc.js
const PC = {
    async load() {
        const area = document.getElementById('pc-table');
        if (area) area.innerHTML = '<div class="text-center py-4"><span class="loading"></span> Memuat data PC...</div>';
        
        try {
            const data = await API.pc.list();
            const list = data.pc_list || [];
            this.render(list);
        } catch (err) {
            console.error("PC Load Error:", err);
            Toast.error('Gagal memuat daftar PC');
        }
    },

    render(pcList) {
        const container = document.getElementById('pc-table');
        if (!container) return;

        if (!pcList || pcList.length === 0) {
            container.innerHTML = '<div class="text-center text-gray-500 py-10 border border-dashed border-gray-800 rounded">Belum ada PC terdaftar</div>';
            return;
        }

        container.innerHTML = `
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="text-xs uppercase text-gray-500 border-b border-gray-800">
                            <th class="p-3">Kode</th>
                            <th class="p-3">Nama PC</th>
                            <th class="p-3">IP Address</th>
                            <th class="p-3">MAC Address</th>
                            <th class="p-3">Grup</th>
                            <th class="p-3">Status</th>
                            <th class="p-3 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="text-sm">
                        ${pcList.map(pc => `
                            <tr class="border-b border-gray-800/50 hover:bg-gray-800/20 transition">
                                <td class="p-3 font-mono font-bold text-blue-400">${pc.kode}</td>
                                <td class="p-3 text-gray-300">${pc.nama || '<span class="text-gray-600">-</span>'}</td>
                                <td class="p-3 font-mono text-xs text-gray-400">${pc.ip_address || '-'}</td>
                                <td class="p-3 font-mono text-xs text-gray-500">${pc.mac_address || '-'}</td>
                                <td class="p-3">
                                    <span class="px-2 py-0.5 text-[10px] font-bold rounded bg-gray-800 border border-gray-700">
                                        ${(pc.grup || 'reguler').toUpperCase()}
                                    </span>
                                </td>
                                <td class="p-3">
                                    ${pc.aktif 
                                        ? '<span class="text-green-500 font-semibold text-xs flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-green-500"></span> Aktif</span>' 
                                        : '<span class="text-red-500 font-semibold text-xs flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-red-500"></span> Nonaktif</span>'}
                                </td>
                                <td class="p-3 text-right">
                                    <button class="text-blue-500 hover:text-blue-400 mr-3 p-1" onclick="PC.edit(${pc.id})" title="Edit PC">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <button class="text-red-500 hover:text-red-400 p-1 font-bold" onclick="PC.delete(${pc.id})" title="Hapus PC">
                                        Hapus
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    },

    async add() {
        const data = {
            kode: document.getElementById('inp-pc-kode').value.trim(),
            nama: document.getElementById('inp-pc-nama').value.trim(),
            ip_address: document.getElementById('inp-pc-ip').value.trim(),
            mac_address: document.getElementById('inp-pc-mac').value.trim().toUpperCase(),
            grup: document.getElementById('inp-pc-grup').value
        };

        if (!data.kode) return Toast.error('Kode PC wajib diisi');
        
        try {
            await API.pc.create(data);
            Toast.success(`PC ${data.kode} berhasil ditambahkan`);
            this.load();
            this.clearForm();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    // 🟢 Edit dinamis dengan Promise.all
    async edit(id) {
        try {
            const [pcResponse, grupResponse] = await Promise.all([
                API.pc.list(),
                API.grup.list()
            ]);

            const listPc = pcResponse.pc_list || [];
            const pc = listPc.find(p => p.id === id);
            
            if (!pc) return Toast.error('PC tidak ditemukan di sistem');
            
            const groups = grupResponse.grup || [];
            this.showEditModal(pc, groups);
        } catch (err) {
            Toast.error('Gagal mengambil data untuk edit');
        }
    },

    showEditModal(pc, groups) {
        // 🟢 Generate opsi grup dari database
        const grupOptions = groups.map(g => `
            <option value="${g.nama}" ${pc.grup === g.nama ? 'selected' : ''}>
                ${g.nama.toUpperCase()}
            </option>
        `).join('');

        const formHtml = `
            <div class="p-1">
                <h3 class="text-lg font-bold mb-4 text-blue-400 border-b border-gray-800 pb-2 uppercase">Edit PC: ${pc.kode}</h3>
                <div class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-[10px] text-gray-500 uppercase block mb-1">Kode PC</label>
                            <input type="text" id="edit-pc-kode" class="form-input bg-gray-900 text-gray-500 border-gray-800 cursor-not-allowed" value="${pc.kode}" readonly disabled title="Kode PC tidak dapat diubah">
                        </div>
                        <div>
                            <label class="text-[10px] text-gray-500 uppercase block mb-1">Grup (Zona)</label>
                            <select id="edit-pc-grup" class="form-input">
                                ${grupOptions}
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class="text-[10px] text-gray-500 uppercase block mb-1">Nama / Alias</label>
                        <input type="text" id="edit-pc-nama" class="form-input" value="${Utils.escapeHtml(pc.nama || '')}">
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-[10px] text-gray-500 uppercase block mb-1">IP Address</label>
                            <input type="text" id="edit-pc-ip" class="form-input font-mono text-sm" value="${pc.ip_address || ''}">
                        </div>
                        <div>
                            <label class="text-[10px] text-gray-500 uppercase block mb-1">MAC Address</label>
                            <input type="text" id="edit-pc-mac" class="form-input font-mono text-sm" value="${pc.mac_address || ''}">
                        </div>
                    </div>
                </div>
                <div class="flex gap-2 justify-end mt-6">
                    <button class="px-4 py-2 text-sm text-gray-500 hover:text-white" onclick="Modal.closeModal()">Batal</button>
                    <button class="btn btn-primary px-6" onclick="PC.doEdit(${pc.id})">Simpan Perubahan</button>
                </div>
            </div>
        `;
        
        Modal.show(formHtml);
    },

    async doEdit(id) {
        const data = {
            nama: document.getElementById('edit-pc-nama').value.trim(),
            ip_address: document.getElementById('edit-pc-ip').value.trim(),
            mac_address: document.getElementById('edit-pc-mac').value.trim().toUpperCase(),
            grup: document.getElementById('edit-pc-grup').value
        };

        try {
            await API.pc.update(id, data);
            Toast.success('Data PC berhasil diperbarui');
            Modal.closeModal();
            this.load();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    async delete(id) {
        Modal.confirm('Yakin ingin menghapus PC ini dari sistem?', async () => {
            try {
                await API.pc.delete(id);
                Toast.success('PC berhasil dihapus');
                this.load();
            } catch (err) {
                Toast.error(err.message);
            }
        });
    },

    async addBatch() {
        const data = {
            prefix: document.getElementById('inp-batch-prefix').value.trim(),
            start: parseInt(document.getElementById('inp-batch-start').value),
            end: parseInt(document.getElementById('inp-batch-end').value),
            grup: document.getElementById('inp-batch-grup').value,
            ip_base: document.getElementById('inp-batch-ip').value.trim()
        };

        if (isNaN(data.start) || isNaN(data.end)) return Toast.error('Nomor urut tidak valid');
        if (data.start > data.end) return Toast.error('Nomor akhir harus lebih besar dari awalan');
        if (data.end - data.start > 100) return Toast.error('Maksimal tambah 100 PC sekaligus');

        try {
            const result = await API.pc.batch(data);
            Toast.success(`Berhasil menambahkan ${result.added} PC baru`);
            if (result.errors && result.errors.length) {
                console.warn("Beberapa PC gagal ditambahkan:", result.errors);
                Toast.error('Beberapa PC gagal ditambahkan (cek console)');
            }
            this.load();
            this.clearBatchForm();
        } catch (err) {
            Toast.error(err.message);
        }
    },

    clearForm() {
        ['inp-pc-kode', 'inp-pc-nama', 'inp-pc-ip', 'inp-pc-mac'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = '';
        });
        
        const grup = document.getElementById('inp-pc-grup');
        if (grup && grup.options.length > 0) grup.selectedIndex = 0;
    },

    clearBatchForm() {
        const els = {
            'inp-batch-prefix': 'PC-',
            'inp-batch-start': '1',
            'inp-batch-end': '10',
            'inp-batch-ip': ''
        };
        
        for (const [id, val] of Object.entries(els)) {
            const el = document.getElementById(id);
            if (el) el.value = val;
        }

        const grup = document.getElementById('inp-batch-grup');
        if (grup && grup.options.length > 0) grup.selectedIndex = 0;
    }
};