# app/__init__.py
from flask import Flask
from flask_cors import CORS
import os

from app.models.base import db
from app.config import Config

def create_app():
    app = Flask(__name__, template_folder='templates')
    app.config.from_object(Config)

    CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)

    db.init_app(app)

    os.makedirs("logs", exist_ok=True)

    # Import blueprints
    from app.routes import (
        auth_bp,
        auth_kasir_bp,
        blackout_bp,
        client_bp,
        dashboard_bp,
        member_bp,
        paket_bp,
        pc_bp,
        report_bp,
        sesi_bp,
        grup_bp,
    )

    app.register_blueprint(dashboard_bp, url_prefix="/kasir")
    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(auth_kasir_bp, url_prefix="/api/kasir")
    app.register_blueprint(client_bp, url_prefix="/client")
    app.register_blueprint(member_bp, url_prefix="/api")
    app.register_blueprint(paket_bp, url_prefix="/api/paket")
    app.register_blueprint(pc_bp, url_prefix="/api")
    app.register_blueprint(report_bp, url_prefix="/api/report")
    app.register_blueprint(sesi_bp, url_prefix="/api/sesi")
    app.register_blueprint(grup_bp, url_prefix="/api/grup")
    app.register_blueprint(blackout_bp, url_prefix="/api/blackout")

    with app.app_context():
        db.create_all()


    return app